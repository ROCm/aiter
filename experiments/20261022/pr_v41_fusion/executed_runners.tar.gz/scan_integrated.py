import os,json,runpy
from pathlib import Path
cases=[dict(batch=t//4,q_per_request=4,heads=128,long_rows=s,long_topk=k) for t,s,k in [(16,8192,1024),(320,8192,128),(1024,8192,1024),(512,32768,1024)]]
os.environ['INTEGRATED']='1';os.environ['SCAN']='1';os.environ['SCAN_CASES']=json.dumps(cases)
runpy.run_path(str(Path(__file__).with_name('bench.py')),run_name='__main__')
