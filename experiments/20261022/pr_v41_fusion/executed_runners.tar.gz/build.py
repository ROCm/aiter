"""Build isolated PR-based fusion candidates; never edit the retained baseline."""
import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

BASE = Path('/home/jun_chen2_qle/yzhou_aiter')
PR = BASE/'aiter-pr6675-20261021'
WORK = BASE/'fp8-qk-pr-fusion-20261022'
LLVM = BASE/'fp8-qk-pr-reference-20261022/toolchain/bin'
WORK.mkdir(exist_ok=True)
ORIGINAL = PR/'csrc/kernels/mla/opus'
HEADER = 'mla_v41_prefill_a8w8_16mx4_64nx1.hpp'
ENTRY = HEADER.replace('.hpp', '.cu')

def replace(s, a, b):
    assert s.count(a) == 1, (a[:120], s.count(a))
    return s.replace(a,b)

extra_fields = '''
    float* max_ptr;
    unsigned char* output_q_ptr;
    unsigned char* output_s_ptr;
    const void* cos_ptr;
    const void* sin_ptr;
    const void* positions_ptr;
    const void* raw_q_ptr;
    float* debug_ptr;
    int positions64;
    int q_is_rotated;
    int cache_mode;
    int page_size;
    int cache_rows;
    int prefix_capacity;
    long long pool_bytes;
    long long scale_bytes;
    long long data_page_stride;
    long long scale_page_stride;
'''

helpers = r'''
__device__ inline float bf32(opus::bf16_t x) {
    return __uint_as_float(uint32_t(__builtin_bit_cast(uint16_t, x)) << 16);
}
__device__ inline float mul_exact(float x, float y) {
    float z; asm("v_mul_f32 %0, %1, %2" : "=v"(z) : "v"(x), "v"(y)); return z;
}
__device__ inline float add_exact(float x, float y) {
    float z; asm("v_add_f32 %0, %1, %2" : "=v"(z) : "v"(x), "v"(y)); return z;
}
template<class T>
__device__ __forceinline__ int prepare_q(const opus_mla_v41_prefill_kargs& a,char* smem,int warp,int lane,int t,int hs) {
    using namespace opus;
    const int64_t pos=a.positions64 ? reinterpret_cast<const int64_t*>(a.positions_ptr)[t]
                                    : reinterpret_cast<const int*>(a.positions_ptr)[t];
    const auto* cs=reinterpret_cast<const bf16_t*>(a.cos_ptr)+pos*32;
    const auto* sn=reinterpret_cast<const bf16_t*>(a.sin_ptr)+pos*32;
    auto* qdst=smem+k_slot_base<T,Q_SLOT>;
    auto* sd=reinterpret_cast<unsigned char*>(smem+scale_slot_base<T,1>);
    static_for<2>([&](auto ig) {
        const int head=ig.value*32+(lane/8)*4+warp;
        static_for<4>([&](auto id) {
            const int d=id.value*128+lane%8*16;
            auto x=*reinterpret_cast<const vector_t<bf16_t,16>*>(reinterpret_cast<const bf16_t*>(a.raw_q_ptr)+(int64_t(t)*a.H+hs+head)*512+d);
            if constexpr(id.value==3) {
                if (!a.q_is_rotated && lane%8>=4) static_for<8>([&](auto i) {
                    constexpr int j=i.value*2;
                    const int ri=(d+j-448)/2;
                    const float x0=bf32(x[j]),x1=bf32(x[j+1]),co=bf32(cs[ri]),si=bf32(sn[ri]);
                    x[j]=static_cast<bf16_t>(add_exact(mul_exact(x0,co),-mul_exact(x1,si)));
                    x[j+1]=static_cast<bf16_t>(add_exact(mul_exact(x0,si),mul_exact(x1,co)));
                });
            }
            vector_t<float,16> f;
            float am=1e-30f;
            static_for<16>([&](auto i){f[i.value]=bf32(x[i.value]);am=fmaxf(am,fabsf(f[i.value]));});
            const auto other=__builtin_amdgcn_ds_bpermute((lane^1)*4,std::bit_cast<unsigned>(am));
            am=fmaxf(am,std::bit_cast<float>(other));
            const unsigned bits=std::bit_cast<unsigned>(am/448.0f);
            const int e=int((bits-1)>>23)+1-127;
            auto q=cast<opus::fp8_t>(f*std::bit_cast<float>(uint32_t(127-e)<<23));
            const int off=((ig.value*4+id.value)*4+warp)*T::smem_brick+lane*16;
            *reinterpret_cast<vector_t<opus::fp8_t,16>*>(qdst+off)=q;
            if (!(lane&1)) sd[head*16+id.value*4+(lane%8)/2]=e+127;
        });
    });
    __builtin_amdgcn_s_barrier();
    return *reinterpret_cast<const int*>(sd+(warp*16+lane%16)*16+lane/16*4);
}
template<class T, class VO>
__device__ __forceinline__ void fused_epilogue(const opus_mla_v41_prefill_kargs& a, const VO& v_o,
                                      int warp, int lane, int token, int h_start) {
    using namespace opus;
    constexpr int VEC = VEC_O2<T>;
    constexpr int NC = O_ELEMS<T> / VEC / PV_GROUPS<T>;
    const int64_t pos = a.positions64 ? reinterpret_cast<const int64_t*>(a.positions_ptr)[token]
                                     : reinterpret_cast<const int*>(a.positions_ptr)[token];
    auto cs = reinterpret_cast<const bf16_t*>(a.cos_ptr) + pos*32;
    auto sn = reinterpret_cast<const bf16_t*>(a.sin_ptr) + pos*32;
    auto offsets = layout_to_offsets<VEC>(make_layout_o_packed<T>(warp, lane, 512));
    static_for<PV_GROUPS<T>>([&](auto r) {
        const int head_off = (warp+r.value)%PV_GROUPS<T>*16*512;
        static_for<NC>([&](auto c) {
            constexpr int base = (r.value*NC+c.value)*VEC;
            auto buf = cast<bf16_t>(slice(v_o, number<base>{}, number<base+VEC>{}));
            auto* p = reinterpret_cast<u32_t*>(&buf);
            auto r0 = __builtin_amdgcn_permlane16_swap(p[0],p[2],false,true);
            auto r1 = __builtin_amdgcn_permlane16_swap(p[1],p[3],false,true);
            p[0]=r0[0]; p[2]=r0[1]; p[1]=r1[0]; p[3]=r1[1];
            const int off = offsets[c.value]+head_off;
            const int d = off%512;
            const int64_t global = (int64_t(token)*a.H+h_start)*512+off;
            if (a.out_ptr) *reinterpret_cast<vector_t<bf16_t,8>*>(reinterpret_cast<bf16_t*>(a.out_ptr)+global)=buf;
            vector_t<float,8> x;
            static_for<8>([&](auto i) { x[i.value]=bf32(buf[i.value]); });
            if (warp == 3 && c.value >= 2) {
                static_for<4>([&](auto i) {
                    constexpr int j = i.value*2;
                    const int ri = (d+j-448)/2;
                    const float co=bf32(cs[ri]), si=bf32(sn[ri]), x0=x[j], x1=x[j+1];
                    x[j]=add_exact(mul_exact(x0,co),mul_exact(x1,si));
                    x[j+1]=add_exact(mul_exact(x1,co),-mul_exact(x0,si));
                });
            }
            float am=1e-8f;
            static_for<8>([&](auto i) {am=fmaxf(am,fabsf(x[i.value]));});
            auto mx=[](float x,float y){return fmaxf(x,y);};
            am=lane_swap_reduce<32>(am,mx);
            am=lane_swap_reduce<16>(am,mx);
            const unsigned bits=__float_as_uint(am/448.0f);
            const int e=int((bits-1)>>23)+1-127;
            const float mul=__uint_as_float(uint32_t(127-e)<<23);
            auto q=cast<opus::fp8_t>(x*mul);
            *reinterpret_cast<uint64_t*>(a.output_q_ptr+global)=__builtin_bit_cast(uint64_t,q);
            if (lane<16) a.output_s_ptr[global/512*16+d/32]=e+127;
            if (a.debug_ptr) *reinterpret_cast<vector_t<float,8>*>(a.debug_ptr+global)=x;
        });
    });
}
'''

def source(general=False):
    h=(ORIGINAL/HEADER).read_text()
    h=replace(h, '    v_v_t<T> ones;', '')
    h=replace(h, '                                  typename T::D_ACC m_row, typename T::D_ACC temperature_scale) {',
        '                                  typename T::D_ACC m_row, typename T::D_ACC temperature_scale, typename T::D_ACC& true_max) {')
    h=replace(h, '        st.row_max = lane_swap_reduce<16>(st.row_max, fmax) * temperature_scale;',
        '        st.row_max = lane_swap_reduce<16>(st.row_max, fmax) * temperature_scale;\n        true_max = fmax(true_max, st.row_max);')
    h=replace(h, '        if constexpr (k > 0) v_s[k - 1] = __builtin_amdgcn_exp2f(v_s[k - 1]);', '''
        if constexpr (k > 0) {
            v_s[k - 1] = __builtin_amdgcn_exp2f(v_s[k - 1]);
            if constexpr (k == 1) st.sum_acc[0] = v_s[k - 1];
            else st.sum_acc[0] += v_s[k - 1];
        }''')
    begin=h.index('        auto mfma_sum = make_mfma<D_PV, D_PV, D_ACC>')
    end=h.index('\n    }\n}',begin)
    h=h[:begin]+'''        auto sum=[](D_ACC x,D_ACC y) {return x+y;};
        if constexpr (OP == SM_SUM_OP<T>) st.sum_acc[0]=lane_swap_reduce<32>(st.sum_acc[0],sum);
        else st.sum_acc[0]=lane_swap_reduce<16>(st.sum_acc[0],sum);'''+h[end:]
    begin=h.index('    static_for<vector_traits<v_v_t<T>>::size()>')
    end=h.index('    auto sm_op',begin)
    h=h[:begin]+h[end:]
    h=replace(h,'softmax_op<T, decltype(k)::value>(v_s[B], p_of(buf), st, m_row, temperature_scale);',
        'softmax_op<T, decltype(k)::value>(v_s[B], p_of(buf), st, m_row, temperature_scale, true_max);')
    h=replace(h, '                                  typename T::D_ACC temperature_scale) {',
        '                                  typename T::D_ACC temperature_scale, typename T::D_ACC& true_max) {')
    h=replace(h,'    D_ACC l_row = D_ACC(0.0f);','    D_ACC l_row = D_ACC(0.0f);\n    D_ACC true_max = -numeric_limits<D_ACC>::infinity();')
    assert h.count('v_o, m_row, l_row, temperature_scale);')==2
    h=h.replace('v_o, m_row, l_row, temperature_scale);','v_o, m_row, l_row, temperature_scale, true_max);')
    h=replace(h,'    const bool has_sink = kargs.attn_sink_ptr != nullptr;', '''
    if (kargs.max_ptr && lane_id < 16 && head < kargs.H)
        kargs.max_ptr[int64_t(q_token_idx)*kargs.H+head]=true_max*0.69314718056f;
    const bool has_sink = kargs.attn_sink_ptr != nullptr;''')
    h=replace(h,'// ------------------------------------------------------------------------------------ driver',helpers+'\n// ------------------------------------------------------------------------------------ driver')
    begin=h.index('    auto v_q_scale = load<T::VEC_SCALE>(g_q_scale')
    end=h.index('\n\n    // Q is loaded',begin)
    h=h[:begin]+'''#if RAW_Q
    const int scale_q=prepare_q<T>(kargs,smem,warp_id,lane_id,q_token_idx,h_block_start);
#else
'''+h[begin:end]+'''\n#endif'''+h[end:]
    h=replace(h,'    auto issue_q = [&] {','    auto issue_q = [&] {\n#if RAW_Q\n        return;\n#endif')
    if general:
        h=replace(h,'    __shared__ char smem[T::smem_bytes()];','    __shared__ __align__(16) char smem[T::smem_bytes()+2*68*sizeof(int)];')
        h=replace(h,'    const int page_idx_begin = kv_indptr[q_token_idx];\n    const int valid_kv_len   = kv_indptr[q_token_idx + 1] - page_idx_begin;', '''
    if (!kv_indptr) return;
    const int cap=kargs.cache_mode ? kargs.prefix_capacity : 0x7fffffff;
    const int page_idx_begin=min(cap,max(0,kv_indptr[q_token_idx]));
    const int valid_kv_len=max(page_idx_begin,min(cap,kv_indptr[q_token_idx+1]))-page_idx_begin;''')
        h=replace(h,'    vector_t<int, T::smem_n_sub_tile_rpt> kv_pages;','    vector_t<int64_t, T::smem_n_sub_tile_rpt> kv_pages;')
        h=replace(h,'            kv_pages[ig.value] = load<1>(g_kv_indices, min(kv_rows[ig.value] + tile_idx * T::KV_TILE_SIZE, valid_kv_len - 1))[0];', '''
            const int off=min(kv_rows[ig.value]+tile_idx*T::KV_TILE_SIZE,valid_kv_len-1);
            kv_pages[ig.value]=kargs.cache_mode==1 ? reinterpret_cast<const int64_t*>(kv_indices)[page_idx_begin+off]
                                                  : int64_t(load<1>(g_kv_indices,off)[0]);''')
        a=h.index('        auto kv_gmem  = page_gmem_bases<T, T::VEC_KV>')
        z=h.index('        return [=](auto idx)',a)
        h=h[:a]+'''
        auto scl_lds=scale_lds_bases<T,SLOT>(smem,u_sk_scale);
        opus::array<const D_ATTN*,T::smem_n_sub_tile_rpt> kv_gmem,scl_gmem;
        auto* flags=reinterpret_cast<int*>(smem+T::smem_bytes())+SLOT*68;
        bool all_live=true;
        static_for<T::smem_n_sub_tile_rpt>([&](auto ig) {
            const int64_t id=kv_pages[ig.value];
            int64_t data_off=0,scale_off=0;
            bool live=false;
            if (kargs.cache_mode==1) {
                data_off=static_cast<uint64_t>(id)>>1;
                scale_off=data_off+512;
                live=id>=0 && (id&1) && !(data_off&3) && kargs.pool_bytes>=528 && data_off<=kargs.pool_bytes-528;
            } else if (kargs.cache_mode==2) {
                const int64_t safe=id>=0 && id<kargs.cache_rows ? id : 0;
                data_off=safe/kargs.page_size*kargs.data_page_stride+safe%kargs.page_size*512;
                scale_off=safe/kargs.page_size*kargs.scale_page_stride+safe%kargs.page_size*16;
                live=id>=0 && id<kargs.cache_rows && data_off<=kargs.pool_bytes-512 && scale_off<=kargs.scale_bytes-16;
            } else {
                data_off=id*kargs.stride_kv_page; scale_off=id*kargs.stride_kv_scale_page;
                live=id>=0 && id<kargs.total_pages;
            }
            const auto* dp=live ? p_kv+data_off : reinterpret_cast<const D_ATTN*>(safe_kv);
            const auto* sp=live ? (kargs.cache_mode==1 ? p_kv+scale_off : p_scale+scale_off) : reinterpret_cast<const D_ATTN*>(safe_kv+512);
            kv_gmem[ig.value]=dp+(lane_id%8)*16;
            scl_gmem[ig.value]=sp+(lane_id%4)*4;
            if (!(lane_id%8)) flags[ig.value*32+(lane_id/8)*4+warp_id]=live;
            all_live=all_live && live;
        });
        const bool wave_live=__builtin_amdgcn_ballot_w64(all_live)==~uint64_t(0);
        if (lane_id==0) flags[64+warp_id]=wave_live;
'''+h[z:]
        a=h.index('        if (__builtin_expect(valid_rows < T::KV_TILE_SIZE, 0)) {')
        z=h.index('        if constexpr (PREV) write_fac',a)
        h=h[:a]+'''
        auto* flags=reinterpret_cast<const int*>(smem+T::smem_bytes())+CUR*68;
        const bool full=flags[64] && flags[65] && flags[66] && flags[67] && valid_rows>=64;
        if (!full) static_for<S_ELEMS<T>>([&](auto i) {
            constexpr int e=i.value/ACC_PER_TILE<T>,j=i.value%ACC_PER_TILE<T>;
            const int row=e*T::W_N+lane_id/T::W_N*ACC_PER_TILE<T>+j;
            if (row>=valid_rows || !flags[row]) v_s[CUR][i.value]=-numeric_limits<typename T::D_ACC>::infinity();
        });
'''+h[z:]
        h=replace(h,'namespace opus_mla_v41_prefill_a8w8_16mx4_64nx1 {',
            'namespace opus_mla_v41_prefill_a8w8_16mx4_64nx1 {\n__device__ __constant__ __align__(16) unsigned char safe_kv[528]={'+','.join(['0']*512+['127']*16)+'};')
    h=replace(h,'    store_o_packed<T>(g_o, v_o, make_layout_o_packed<T>(warp_id, lane_id, kargs.stride_o_h), warp_id, kargs.stride_o_h);', '''
#if FUSE_OUTPUT
    fused_epilogue<T>(kargs,v_o,warp_id,lane_id,q_token_idx,h_block_start);
#else
    store_o_packed<T>(g_o, v_o, make_layout_o_packed<T>(warp_id, lane_id, kargs.stride_o_h), warp_id, kargs.stride_o_h);
#endif''')
    return h.replace('__uint_as_float(', 'std::bit_cast<float>(').replace('__float_as_uint(', 'std::bit_cast<unsigned>(')

def prechecked(h):
    h=h.replace('fwd(opus_mla_v41_prefill_kargs kargs)', 'fwd(opus_mla_v41_prefill_kargs kargs, char* smem)')
    h=h.replace('    __shared__ __align__(16) char smem[T::smem_bytes()+2*68*sizeof(int)];','')
    h=h.replace('template<class T, class QI, class QR>','template<class T, bool CHECKED, class QI, class QR>')
    h=h.replace('template<class Traits>','template<class Traits, bool CHECKED>')
    h=h.replace('attention_segment<T>(', 'attention_segment<T,CHECKED>(')
    h=h.replace('bool live=false;', 'bool live=true;')
    h=h.replace('live=id>=0', 'if constexpr(CHECKED) live=id>=0')
    h=h.replace('if (!(lane_id%8)) flags', 'if (CHECKED && !(lane_id%8)) flags')
    h=h.replace('if (lane_id==0) flags[64+warp_id]=wave_live;', 'if (CHECKED && lane_id==0) flags[64+warp_id]=wave_live;')
    h=h.replace('        auto* flags=reinterpret_cast<const int*>(smem+T::smem_bytes())+CUR*68;', '        if constexpr(CHECKED) {\n        auto* flags=reinterpret_cast<const int*>(smem+T::smem_bytes())+CUR*68;')
    h=h.replace('        if constexpr (PREV) write_fac', '''        } else if (valid_rows<T::KV_TILE_SIZE) mask_tail_tile<T>(v_s[CUR],valid_rows,lane_id);
        if constexpr (PREV) write_fac''')
    h=h.replace('(st.row_max - m_row) <= RESCALE_THRESHOLD', '((st.row_max - m_row) <= RESCALE_THRESHOLD || st.row_max == -numeric_limits<D_ACC>::infinity())')
    h=h.replace('st.neg_max = -st.row_max;', 'st.neg_max = st.row_max == -numeric_limits<D_ACC>::infinity() ? D_ACC(0) : -st.row_max;')
    h+=r'''
__device__ __forceinline__ bool indices_valid(const opus_mla_v41_prefill_kargs& a) {
    __shared__ int invalid_wave[4];
    const int t=blockIdx.x,lane=threadIdx.x%64,warp=threadIdx.x/64;
    bool valid=true;
    for(int segment=0;segment<2;++segment) {
        const auto* ptr=segment ? a.kv_indptr_extend : a.kv_indptr_prefix;
        const auto* ids=segment ? a.kv_indices_extend : a.kv_indices_prefix;
        if(!ptr) continue;
        const int begin=min(a.prefix_capacity,max(0,ptr[t]));
        const int end=max(begin,min(a.prefix_capacity,ptr[t+1]));
        for(int i=begin+threadIdx.x;i<end;i+=256) {
#if CACHE_MODE == 1
            const int64_t id=reinterpret_cast<const int64_t*>(ids)[i];
            valid=valid && id>=0 && (id&7)==1 && a.pool_bytes>=528 && (uint64_t(id)>>1)<=uint64_t(a.pool_bytes-528);
#else
            const int id=ids[i];
            valid=valid && id>=0 && id<a.cache_rows;
#endif
        }
    }
    const bool bad=__builtin_amdgcn_ballot_w64(!valid)!=0;
    if(lane==0) invalid_wave[warp]=bad;
    __builtin_amdgcn_s_barrier();
    const bool good=!(invalid_wave[0] || invalid_wave[1] || invalid_wave[2] || invalid_wave[3]);
    __builtin_amdgcn_s_barrier();
    return good;
}
'''
    return h

manifest=json.loads((WORK/'manifest.json').read_text()) if (WORK/'manifest.json').exists() else {}
variants=[('strict',0),('epilogue',1),('raw',1),('row_prepared',1),('row_raw',1),('legacy_raw',1),('paged128_raw',1),('legacy_check_raw',1),('paged128_check_raw',1),('legacy_check_prepared',1),('paged128_check_prepared',1)]
selected=os.environ.get('VARIANTS','legacy_check_prepared,paged128_check_prepared').split(',')
for tag, fused in variants:
    if tag not in selected:continue
    out=WORK/tag
    if out.exists():
        archive=WORK/'history'/(tag+'_'+str(time.time_ns()))
        archive.parent.mkdir(exist_ok=True)
        shutil.copytree(out,archive)
    out.mkdir(exist_ok=True)
    h=source(tag.startswith(('row_','legacy_','paged')))
    if tag.startswith('legacy_'):
        h=h.replace('kargs.cache_mode','1')
    if tag.startswith('paged128_'):
        h=h.replace('kargs.cache_mode','2').replace('kargs.page_size','128')
        h=h.replace(' && data_off<=kargs.pool_bytes-512 && scale_off<=kargs.scale_bytes-16','')
    if '_check_' in tag:h=prechecked(h)
    (out/HEADER).write_text(h)
    k=(ORIGINAL/'mla_v41_prefill_kargs.h').read_text()
    k=replace(k,'};',extra_fields+'};').replace('== 160','== 280')
    (out/'mla_v41_prefill_kargs.h').write_text(k)
    entry=(ORIGINAL/ENTRY).read_text()
    if '_check_' in tag:
        start=entry.index('    opus_mla_v41_prefill_a8w8_16mx4_64nx1_fwd<')
        entry=entry[:start]+'''    using Traits=opus_mla_v41_prefill_a8w8_16mx4_64nx1_traits<16,64,4,fp8_t,bf16_t,bf16_t>;
    __shared__ __align__(16) char smem[Traits::smem_bytes()+2*68*sizeof(int)];
    if(indices_valid(kargs)) opus_mla_v41_prefill_a8w8_16mx4_64nx1_fwd<Traits,false>(kargs,smem);
    else opus_mla_v41_prefill_a8w8_16mx4_64nx1_fwd<Traits,true>(kargs,smem);
}
'''
    (out/ENTRY).write_text('#define CACHE_MODE '+str(1 if tag.startswith('legacy') else 2)+'\n#define FUSE_OUTPUT '+str(fused)+'\n#define RAW_Q '+str(int(tag.endswith('raw')))+'\n'+entry)
    args=['/opt/rocm/bin/hipcc','-x','hip',str(out/ENTRY),'-I'+str(PR/'csrc/include'),
        '-I'+str(PR/'csrc/kernels/mla'),'-I'+str(ORIGINAL),'-std=c++20','-O3','--offload-arch=gfx950',
        '-D__HIPCC_RTC__','-ffast-math','-fgpu-flush-denormals-to-zero','-fno-offload-uniform-block',
        '-mllvm','--amdgpu-kernarg-preload-count=32','-mllvm','--lsr-drop-solution=1',
        '-mllvm','-amdgpu-early-inline-all=false','-mllvm','-amdgpu-function-calls=true',
        '-mllvm','-enable-post-misched=1','-Rpass-analysis=kernel-resource-usage','--genco','-o',str(out/'kernel.co')]
    with (out/'build.log').open('w') as log:
        p=subprocess.run(args,env=dict(os.environ,HIP_CLANG_PATH=str(LLVM)),stdout=log,stderr=subprocess.STDOUT,timeout=300)
    print(tag,(out/'build.log').read_text()[-6500:],flush=True)
    assert p.returncode==0,tag
    target,=[x for x in subprocess.check_output([str(LLVM/'clang-offload-bundler'),'--type=o','--list','--input='+str(out/'kernel.co')],text=True).splitlines() if 'gfx950' in x]
    subprocess.run([str(LLVM/'clang-offload-bundler'),'--type=o','--unbundle','--targets='+target,
        '--input='+str(out/'kernel.co'),'--output='+str(out/'kernel.hsaco')],check=True)
    metadata=subprocess.check_output(['/opt/rocm/llvm/bin/llvm-readelf','-n',str(out/'kernel.hsaco')],text=True)
    (out/'metadata.txt').write_text(metadata)
    manifest[tag]={'elf_path':str(out/'kernel.hsaco'),'sha256':hashlib.sha256((out/'kernel.hsaco').read_bytes()).hexdigest()}
    (WORK/'manifest.json').write_text(json.dumps(manifest,indent=2))
