"""Exercise real API index contracts with the independent existing FP8 QK oracle."""
from validate import *
import sys,importlib.util
repo=BASE/'aiter-dsv41-pr-fusion-20261022'
sys.path.insert(0,str(repo))
sys.path.insert(0,str(repo/'op_tests'))
import test_fused_dsv41_fp8_qk as oracle

def case(page,raw,positions64,kind):
    args,kw,rows,kv,sink=oracle.fixture(128,page,raw)
    q,pool,ids,ptr,cos,sin,pos=args
    if positions64:pos=pos.long()
    n=kv.shape[0]
    if kind=='all_invalid':
        ids.fill_(-1);rows=[torch.full_like(r,-1) for r in rows]
    if kind=='truncated':
        n=83
        if page:
            # Host backed_rows takes the minimum of the actual byte views.
            kw['cache_scales']=kw['cache_scales'][:n*16]
            kw['cache_num_rows']=n
        else:pool=pool[:4+n*528]
        kv=kv[:n]
    if kind=='csr_clamp':
        ptr=ptr.clone();ptr[0]=-10;ptr[1]=-1;ptr[-1]=ids.numel()+113
    t,h,_=q.shape
    a=Kargs()
    q8,qs=quant(rotate(q,cos,sin,pos).bfloat16() if raw else q)
    out=torch.empty_like(q);debug=torch.empty_like(q,dtype=torch.float32)
    mx=torch.empty((t,h),device='cuda');lse=torch.empty_like(mx)
    qo=torch.empty_like(q,dtype=torch.float8_e4m3fn);so=torch.empty((t,h,16),device='cuda',dtype=torch.uint8)
    for name,obj in dict(q_ptr=q8,q_scale_ptr=qs,raw_q_ptr=q,unified_kv_ptr=pool,
        cos_ptr=cos,sin_ptr=sin,positions_ptr=pos,attn_sink_ptr=sink,
        kv_indptr_prefix=ptr,kv_indices_prefix=ids,out_ptr=out,lse_ptr=lse,max_ptr=mx,
        output_q_ptr=qo,output_s_ptr=so,debug_ptr=debug).items():setattr(a,name,obj.data_ptr())
    a.N=t;a.H=h;a.stride_q_n=h*512;a.stride_q_h=512;a.stride_q_scale_n=h*16;a.stride_q_scale_h=16
    a.stride_o_n=h*512;a.stride_o_h=512;a.stride_lse_n=h;a.softmax_scale=512**-.5
    a.positions64=positions64;a.q_is_rotated=not raw;a.prefix_capacity=ids.numel();a.pool_bytes=pool.numel()
    a.cache_mode=2 if page else 1;a.cache_rows=n;a.page_size=page
    if page:
        a.unified_kv_scale_ptr=kw['cache_scales'].data_ptr();a.scale_bytes=kw['cache_scales'].numel()
        a.data_page_stride=kw['cache_data_page_stride'];a.scale_page_stride=kw['cache_scale_page_stride']
    tag='paged128_check_raw' if page else 'legacy_check_raw'
    arg=(ct.c_void_p*1)(ct.addressof(a))
    def call():checked(hip.hipModuleLaunchKernel(functions[tag],t,2,1,256,1,1,0,torch.cuda.current_stream().cuda_stream,arg,None))
    call()
    expected,em,el=oracle.dense(q,kv,rows,cos,sin,pos,sink,raw)
    torch.testing.assert_close(mx,em,rtol=1e-4,atol=3e-5)
    torch.testing.assert_close(lse,el,rtol=1e-4,atol=3e-5)
    torch.testing.assert_close(debug,expected,rtol=.02,atol=.008)
    exact=rotate(out,cos,sin,pos,True)
    torch.testing.assert_close(debug,exact,rtol=0,atol=0)
    ex=(exact.reshape(t,h,16,32).abs().amax(-1).clamp_min(1e-8)/448).log2().ceil()
    eq=(exact.reshape(t,h,16,32)/torch.exp2(ex)[...,None]).to(torch.float8_e4m3fn).reshape_as(qo)
    torch.testing.assert_close(qo.view(torch.uint8),eq.view(torch.uint8),rtol=0,atol=0)
    torch.testing.assert_close(so,(ex+127).to(torch.uint8),rtol=0,atol=0)
    saved=[x.clone() for x in [qo,so,mx,lse,debug]]
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):call()
    for x in [qo,so,mx,lse,debug]:x.view(torch.uint8).fill_(255)
    graph.replay()
    for x,y in zip([qo,so,mx,lse,debug],saved):torch.testing.assert_close(x.view(torch.uint8),y.view(torch.uint8),rtol=0,atol=0)
    print('PASS',page,raw,positions64,kind,flush=True)

for page in [0,128]:
    for raw in [False,True]:
        for pos64 in [False,True]:
            for kind in ['mixed','all_invalid','truncated','csr_clamp']:case(page,raw,pos64,kind)
print('32 CONTRACT CASES PASSED',flush=True)
