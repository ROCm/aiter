"""Independent oracle and graph validation of the experimental fused code objects."""
import ast
from pathlib import Path
WORK=Path('/home/jun_chen2_qle/yzhou_aiter/fp8-qk-pr-fusion-20261022')
src=(WORK/'reference.py').read_text().split('def case(')[0]
src=src.replace("WORK = BASE/'fp8-qk-pr-reference-20261022'", "WORK = BASE/'fp8-qk-pr-fusion-20261022'")
src=src.replace("assert ct.sizeof(Kargs) == 160", """KargsBase = Kargs
class Kargs(KargsBase):
    _fields_=[(name,ct.c_void_p) for name in ['max_ptr','output_q_ptr','output_s_ptr','cos_ptr','sin_ptr','positions_ptr','raw_q_ptr','debug_ptr']]+[(name,ct.c_int) for name in ['positions64','q_is_rotated','cache_mode','page_size','cache_rows','prefix_capacity']]+[(name,ct.c_int64) for name in ['pool_bytes','scale_bytes','data_page_stride','scale_page_stride']]
assert ct.sizeof(Kargs) == 280""")
src=src.replace("manifest = json.loads((WORK/'kernel_build_manifest.json').read_text())", """manifest = {'artifacts':json.loads((WORK/'manifest.json').read_text())}
manifest['artifacts']['prebuilt']={'elf_path':str(BASE/'fp8-qk-pr-reference-20261022/source_build/prebuilt.hsaco')}""")
exec(compile(src,'reference_helpers','exec'))
tree=ast.parse(test.read_text())
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='rotate'],type_ignores=[]),str(test),'exec'))

def make_case(t,h,s,counts=None):
    torch.manual_seed(22000+t+h+s)
    gain=torch.exp2(torch.arange(16,device='cuda').float()%7-3).repeat_interleave(32)
    k8,ks=quant((torch.randn(s,512,device='cuda')*.2*gain).bfloat16())
    packed=torch.cat((k8.view(torch.uint8),ks),-1)
    kv,scales=packed[:,:512].view(torch.float8_e4m3fn),packed[:,512:]
    raw=(torch.randn(t,h,512,device='cuda')*.2*gain.flip(0)).bfloat16()
    angles=torch.randn(257,32,device='cuda')
    cos,sin=angles.cos().bfloat16(),angles.sin().bfloat16()
    pos=(torch.arange(t,device='cuda')%257).int()
    q8,qs=quant(rotate(raw,cos,sin,pos).bfloat16())
    counts=counts or [(512 if h==64 else 1024,128)]*t
    rows_p=[((torch.arange(p,device='cuda')*17+i*67)%s).int() for i,(p,e) in enumerate(counts)]
    rows_e=[((torch.arange(e,device='cuda')*31+i*19+s//2)%s).int() for i,(p,e) in enumerate(counts)]
    pp=torch.tensor([0]+[p for p,e in counts],device='cuda',dtype=torch.int32).cumsum(0).int()
    ep=torch.tensor([0]+[e for p,e in counts],device='cuda',dtype=torch.int32).cumsum(0).int()
    pi,ei=torch.cat(rows_p),torch.cat(rows_e)
    sink=torch.linspace(-3,3,h,device='cuda');sink[::11]=-torch.inf
    args,outputs,calls={}, {}, {}
    for tag in functions:
        o=torch.empty_like(raw);lse=torch.empty((t,h),device='cuda');mx=torch.empty_like(lse)
        qo=torch.empty_like(raw,dtype=torch.float8_e4m3fn);so=torch.empty((t,h,16),device='cuda',dtype=torch.uint8)
        debug=torch.empty_like(raw,dtype=torch.float32)
        a=Kargs(q8.data_ptr(),qs.data_ptr(),kv.data_ptr(),scales.data_ptr(),kv.data_ptr(),scales.data_ptr(),
            sink.data_ptr(),o.data_ptr(),lse.data_ptr(),pp.data_ptr(),pi.data_ptr(),ep.data_ptr(),ei.data_ptr(),
            t,h,s,s,h*512,512,h*16,16,h*512,512,h,528,528,512**-.5,
            mx.data_ptr(),qo.data_ptr(),so.data_ptr(),cos.data_ptr(),sin.data_ptr(),pos.data_ptr(),raw.data_ptr(),debug.data_ptr(),0,0)
        args[tag]=a
        ptr=(ct.c_void_p*1)(ct.addressof(a))
        def call(tag=tag,ptr=ptr):
            checked(hip.hipModuleLaunchKernel(functions[tag],t,(h+63)//64,1,256,1,1,0,torch.cuda.current_stream().cuda_stream,ptr,None))
        calls[tag]=call
        outputs[tag]=[o,lse]+([mx] if tag!='prebuilt' else [])+([qo,so,debug] if tag in ['epilogue','raw','row_prepared','row_raw'] else [])
        call()
    torch.cuda.synchronize()
    qref=decode(q8,qs);kref=decode(kv,scales).bfloat16().float()
    errors=[]
    for i in (range(t) if t<20 else [0,t//2,t-1]):
        ids=torch.cat((rows_p[i],rows_e[i])).long()
        if ids.numel():
            scores=qref[i]@kref[ids].T*512**-.5
            ref=torch.cat((scores,sink[:,None]),-1).softmax(-1)[:,:len(ids)]@kref[ids]
            for tag,out in outputs.items():
                error=relative(out[0][i],ref)
                assert error<.005,(tag,i,error)
                torch.testing.assert_close(out[0][i].float(),ref,rtol=.02,atol=.008)
                if tag!='prebuilt':
                    torch.testing.assert_close(out[1][i],scores.logsumexp(-1),rtol=1e-4,atol=3e-5)
                    torch.testing.assert_close(out[2][i],scores.max(-1).values,rtol=1e-4,atol=3e-5)
                errors.append({'tag':tag,'token':i,'output_l2':error})
        else:
            for tag,out in outputs.items():
                assert torch.count_nonzero(out[0][i])==0
                assert torch.isposinf(out[1][i]).all()
                if tag!='prebuilt':assert torch.isneginf(out[2][i]).all()
    for tag in ['epilogue','raw','row_prepared','row_raw']:
        if tag not in outputs:continue
        out=outputs[tag]
        expected=rotate(out[0],cos,sin,pos,True)
        torch.testing.assert_close(out[5],expected,rtol=0,atol=0)
        groups=expected.reshape(-1,16,32)
        exponent=(groups.abs().amax(-1).clamp_min(1e-8)/448).log2().ceil()
        expected_q=(groups/torch.exp2(exponent)[...,None]).to(torch.float8_e4m3fn).reshape_as(out[3])
        torch.testing.assert_close(out[3].view(torch.uint8),expected_q.view(torch.uint8),rtol=0,atol=0)
        torch.testing.assert_close(out[4].reshape(-1,16),(exponent+127).to(torch.uint8),rtol=0,atol=0)
    graphs={}
    for tag,call in calls.items():
        saved=[x.clone() for x in outputs[tag]]
        graph=torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            for _ in range(4):call()
        for x in outputs[tag]:x.view(torch.uint8).fill_(255)
        graph.replay()
        for x,y in zip(outputs[tag],saved):torch.testing.assert_close(x.view(torch.uint8),y.view(torch.uint8),rtol=0,atol=0)
        graphs[tag]=graph
    samples={tag:[] for tag in graphs}
    for trial in range(8):
        for tag in list(graphs)[::1 if trial%2==0 else -1]:
            start,end=torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(16):graphs[tag].replay()
            end.record();end.synchronize()
            samples[tag].append(start.elapsed_time(end)*1000/64)
    return {'T':t,'H':h,'S':s,'errors':errors,'median_us':{tag:statistics.median(v) for tag,v in samples.items()},'samples_us':samples,'strict_max_lse_pass':True,'epilogue_exact':True,'graph_replay':True}

if __name__=='__main__':
    report={'complete':False,'cases':[]}
    counts=[(0,0),(1,0),(0,1),(31,33),(32,32),(63,1),(64,0),(65,0),(129,65),(1153,0)]
    for t,h,s,c in [(10,64,2048,counts),(10,128,2048,counts),(320,128,8192,None),(560,64,8192,None)]:
        row=make_case(t,h,s,c);report['cases'].append(row)
        (WORK/'validation.json').write_text(json.dumps(report,indent=2))
        print({k:v for k,v in row.items() if k not in ['errors','samples_us']},flush=True)
    report['complete']=True
    (WORK/'validation.json').write_text(json.dumps(report,indent=2))
