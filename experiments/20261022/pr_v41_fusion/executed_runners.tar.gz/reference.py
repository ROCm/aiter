"""Direct HIP-module comparison of source-built and pinned prebuilt attention."""
import os
os.environ['HIP_VISIBLE_DEVICES'] = '6'
os.environ.pop('ROCR_VISIBLE_DEVICES', None)
import ast
import ctypes as ct
import fcntl
import json
import statistics
from pathlib import Path
import torch

BASE = Path('/home/jun_chen2_qle/yzhou_aiter')
WORK = BASE/'fp8-qk-pr-reference-20261022'
lock = open('/tmp/yzhou_dsv41_gpu6.lock', 'w')
fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
torch.set_num_threads(4)
torch.backends.cuda.matmul.allow_tf32 = False
torch.cuda.init()

# Reuse the existing independent torch quantizer, without importing aiter/JIT.
test = BASE/'aiter-dsv41-fp8-qk-pv-opt-20261021/op_tests/test_fused_dsv41_mxfp8.py'
tree = ast.parse(test.read_text())
nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'quantize_fp8']
exec(compile(ast.Module(body=nodes, type_ignores=[]), str(test), 'exec'))

class Kargs(ct.Structure):
    _fields_ = [(name, ct.c_void_p) for name in [
        'q_ptr', 'q_scale_ptr', 'unified_kv_ptr', 'unified_kv_scale_ptr',
        'kv_ptr', 'kv_scale_ptr', 'attn_sink_ptr', 'out_ptr', 'lse_ptr',
        'kv_indptr_prefix', 'kv_indices_prefix', 'kv_indptr_extend', 'kv_indices_extend']]
    _fields_ += [(name, ct.c_int) for name in [
        'N', 'H', 'total_pages', 'total_tokens', 'stride_q_n', 'stride_q_h',
        'stride_q_scale_n', 'stride_q_scale_h', 'stride_o_n', 'stride_o_h',
        'stride_lse_n', 'stride_kv_page', 'stride_kv_scale_page']]
    _fields_ += [('softmax_scale', ct.c_float)]

assert ct.sizeof(Kargs) == 160
assert Kargs.N.offset == 104 and Kargs.softmax_scale.offset == 156
hip = ct.CDLL('/opt/rocm/lib/libamdhip64.so')
hip.hipGetErrorString.argtypes = [ct.c_int]
hip.hipGetErrorString.restype = ct.c_char_p
hip.hipModuleLoad.argtypes = [ct.POINTER(ct.c_void_p), ct.c_char_p]
hip.hipModuleGetFunction.argtypes = [ct.POINTER(ct.c_void_p), ct.c_void_p, ct.c_char_p]
hip.hipModuleLaunchKernel.argtypes = [ct.c_void_p] + [ct.c_uint]*7 + [ct.c_void_p, ct.c_void_p, ct.c_void_p]

def checked(result):
    if result:
        raise RuntimeError(hip.hipGetErrorString(result).decode())

manifest = json.loads((WORK/'kernel_build_manifest.json').read_text())
modules, functions = {}, {}
for tag, artifact in manifest['artifacts'].items():
    modules[tag], functions[tag] = ct.c_void_p(), ct.c_void_p()
    checked(hip.hipModuleLoad(ct.byref(modules[tag]), artifact['elf_path'].encode()))
    checked(hip.hipModuleGetFunction(ct.byref(functions[tag]), modules[tag],
        b'opus_mla_v41_prefill_a8w8_16mx4_64nx1_kernel'))

def quant(x):
    values, codes = quantize_fp8(x)
    return values.reshape_as(x), codes.reshape(*x.shape[:-1], 16)

def decode(values, codes):
    return values.float() * torch.exp2(codes.float()-127).repeat_interleave(32, -1)

def relative(actual, expected):
    return float((actual.float()-expected).norm() / expected.norm().clamp_min(1e-30))

def case(tokens, heads, length, counts=None, sink_enabled=True, lse_enabled=True):
    torch.manual_seed(22000 + tokens + heads + length)
    gain = torch.exp2(torch.arange(16, device='cuda').float()%7-3).repeat_interleave(32)
    k8, ks = quant((torch.randn(length, 512, device='cuda')*.2*gain).bfloat16())
    packed = torch.cat((k8.view(torch.uint8), ks), -1)
    kv, scales = packed[:, :512].view(torch.float8_e4m3fn), packed[:, 512:]
    q8, qs = quant((torch.randn(tokens, heads, 512, device='cuda')*.2*gain.flip(0)).bfloat16())
    if counts is None:
        counts = [(512 if heads == 64 else 1024, 128)] * tokens
    assert len(counts) == tokens
    rows_p, rows_e = [], []
    for i, (p, e) in enumerate(counts):
        # Odd strides permute power-of-two backing lengths and preserve row validity.
        rows_p.append(((torch.arange(p, device='cuda')*17+i*67)%length).int())
        rows_e.append(((torch.arange(e, device='cuda')*31+i*19+length//2)%length).int())
    pp = torch.tensor([0]+[x[0] for x in counts], device='cuda', dtype=torch.int32).cumsum(0).int()
    ep = torch.tensor([0]+[x[1] for x in counts], device='cuda', dtype=torch.int32).cumsum(0).int()
    pi, ei = torch.cat(rows_p), torch.cat(rows_e)
    sink = torch.linspace(-3, 3, heads, device='cuda') if sink_enabled else None
    if sink is not None:
        sink[::11] = -torch.inf
    outputs, args, callbacks = {}, {}, {}
    for tag in functions:
        output = torch.empty_like(q8, dtype=torch.bfloat16)
        lse = torch.empty((tokens, heads), device='cuda') if lse_enabled else None
        args[tag] = Kargs(q8.data_ptr(), qs.data_ptr(), kv.data_ptr(), scales.data_ptr(),
            kv.data_ptr(), scales.data_ptr(), sink.data_ptr() if sink is not None else 0,
            output.data_ptr(), lse.data_ptr() if lse is not None else 0,
            pp.data_ptr(), pi.data_ptr(), ep.data_ptr(), ei.data_ptr(), tokens, heads,
            length, length, q8.stride(0), q8.stride(1), qs.stride(0), qs.stride(1),
            output.stride(0), output.stride(1), heads, kv.stride(0), scales.stride(0), 512**-.5)
        argptr = (ct.c_void_p*1)(ct.addressof(args[tag]))
        def launch(tag=tag, argptr=argptr):
            checked(hip.hipModuleLaunchKernel(functions[tag], tokens, (heads+63)//64, 1,
                256, 1, 1, 0, torch.cuda.current_stream().cuda_stream, argptr, None))
        callbacks[tag] = launch
        outputs[tag] = [output] + ([lse] if lse is not None else [])
        launch()
    torch.cuda.synchronize()
    equality = []
    for a, b in zip(outputs['source'], outputs['prebuilt']):
        equality.append(torch.equal(a.view(torch.uint8), b.view(torch.uint8)))
    result = {'T': tokens, 'H': heads, 'S': length, 'counts': counts if tokens < 20 else counts[0],
              'sink': sink_enabled, 'lse': lse_enabled, 'source_prebuilt_bit_exact': equality,
              'source_prebuilt_output_l2': relative(outputs['source'][0], outputs['prebuilt'][0].float())}
    qref, kvref = decode(q8, qs), decode(kv, scales).bfloat16().float()
    checks = list(range(tokens)) if tokens < 20 else [0, tokens//2, tokens-1]
    errors = []
    lse_failures = []
    for i in checks:
        ix = torch.cat((rows_p[i], rows_e[i])).long()
        if len(ix) == 0:
            for out in outputs.values():
                assert torch.count_nonzero(out[0][i]) == 0
                if lse_enabled:
                    assert torch.isposinf(out[1][i]).all()
            continue
        selected = kvref[ix]
        scores = qref[i] @ selected.T * 512**-.5
        probabilities = (torch.cat((scores, sink[:, None]), -1) if sink is not None else scores).softmax(-1)[:, :len(ix)]
        expected = probabilities @ selected
        for tag, out in outputs.items():
            error = relative(out[0][i], expected)
            errors.append({'token': i, 'tag': tag, 'relative_l2': error})
            assert error < .005, (result, errors[-1])
            torch.testing.assert_close(out[0][i].float(), expected, rtol=.02, atol=.008)
            if lse_enabled:
                expected_lse = scores.logsumexp(-1)
                try:
                    torch.testing.assert_close(out[1][i], expected_lse, rtol=1e-4, atol=3e-5)
                except AssertionError as exc:
                    # Keep the fused contract's tolerance unchanged. Diagnose both
                    # reference binaries even when PR's BF16-P sum fails that contract.
                    lse_failures.append({'token': i, 'tag': tag,
                        'max_absolute_error': float((out[1][i]-expected_lse).abs().max()),
                        'details': str(exc)})
    result['oracle_errors'] = errors
    result['strict_lse_failures'] = lse_failures
    result['strict_lse_pass'] = not lse_failures if lse_enabled else None
    graphs, saved = {}, {tag: [x.clone() for x in out] for tag, out in outputs.items()}
    for tag, launch in callbacks.items():
        for _ in range(3):
            launch()
        graph = torch.cuda.CUDAGraph()
        with torch.cuda.graph(graph):
            for _ in range(4):
                launch()
        graphs[tag] = graph
        for value in outputs[tag]:
            value.view(torch.uint8).fill_(255)
        graph.replay()
        for value, reference in zip(outputs[tag], saved[tag]):
            torch.testing.assert_close(value.view(torch.uint8), reference.view(torch.uint8), rtol=0, atol=0)
    samples = {tag: [] for tag in graphs}
    for repeat in range(8):
        for tag in list(graphs)[::1 if repeat%2 == 0 else -1]:
            start, end = torch.cuda.Event(enable_timing=True), torch.cuda.Event(enable_timing=True)
            start.record()
            for _ in range(16):
                graphs[tag].replay()
            end.record()
            end.synchronize()
            samples[tag].append(start.elapsed_time(end)*1000/64)
    result['samples_us'] = samples
    result['median_us'] = {tag: statistics.median(values) for tag, values in samples.items()}
    result['source_vs_prebuilt_pct'] = (result['median_us']['source']/result['median_us']['prebuilt']-1)*100
    result['graph_replay'] = True
    return result

report = {'complete': False, 'device': str(torch.cuda.get_device_properties(0)), 'cases': []}
def record(value):
    report['cases'].append(value)
    (WORK/'validation.json').write_text(json.dumps(report, indent=2))
    print(json.dumps({k:v for k,v in value.items() if k not in ['samples_us','oracle_errors','counts']}), flush=True)

counts = [(0,0), (1,0), (0,1), (31,33), (32,32), (63,1), (64,0), (65,0), (129,65), (1153,0)]
for h in [64,128]:
    for sink in [False,True]:
        record(case(len(counts), h, 2048, counts, sink))
for t,h,s in [(560,64,8192), (560,64,32768), (960,64,8192), (960,64,32768),
              (128,128,8192), (256,128,8192), (320,128,8192), (320,128,32768), (512,128,8192)]:
    record(case(t,h,s,lse_enabled=False))
report['complete'] = True
report['strict_fused_lse_contract_pass'] = all(x['strict_lse_pass'] is not False for x in report['cases'])
report['all_source_prebuilt_bit_exact'] = all(all(x['source_prebuilt_bit_exact']) for x in report['cases'])
(WORK/'validation.json').write_text(json.dumps(report, indent=2))
