import os,runpy
from pathlib import Path
os.environ['INTEGRATED']='1'
runpy.run_path(str(Path(__file__).with_name('bench.py')),run_name='__main__')
