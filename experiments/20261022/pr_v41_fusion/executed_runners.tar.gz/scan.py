import os,json,runpy
from pathlib import Path
cases=[dict(batch=t//4,q_per_request=4,heads=128,long_rows=8192,long_topk=1024) for t in [16,64,128,256,512,1024,2048]]
cases += [dict(batch=80,q_per_request=4,heads=128,long_rows=8192,long_topk=k) for k in [64,128,256,512,2048]]
os.environ['SCAN']='1';os.environ['SCAN_CASES']=json.dumps(cases)
runpy.run_path(str(Path(__file__).with_name('bench.py')),run_name='__main__')
