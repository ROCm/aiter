"""Same-fixture, same-run comparison against the retained fused binary and PR full path."""
import sys,os,ast,importlib.util,gc
from pathlib import Path
WORK=Path('/home/jun_chen2_qle/yzhou_aiter/fp8-qk-pr-fusion-20261022')
ns={'__name__':'validation_helpers'}
exec(compile((WORK/'validate.py').read_text(),str(WORK/'validate.py'),'exec'),ns)
globals().update({k:v for k,v in ns.items() if k!='__name__'})
os.environ['AITER_JIT_DIR']=str(BASE/'pr6675-results-20261021/jit')
sys.path.insert(0,str(BASE/'aiter-pr6675-20261021'))
sys.path.insert(0,str(BASE/'pr6675-results-20261021'))
import bench_compare as pr
spec=importlib.util.spec_from_file_location('retained_bench',BASE/'decode-pipeline-opt-20261021/bench.py')
b=importlib.util.module_from_spec(spec);spec.loader.exec_module(b)
retained=b.load_module('retained_8512',BASE/'fp8-qk-pv-opt-20261021/release/jit/final/module_fused_dsv41_mxfp8.so')
integrated=b.load_module('integrated_pr_v41',WORK/'jit/final/module_fused_dsv41_mxfp8.so') if os.environ.get('INTEGRATED') else None

def baseline(q,packed,ids,ptr,cos,sin,pos,sink,scale,config=None,module=None,qscale=None):
    module=module or retained
    t,h,_=q.shape
    out=[torch.empty((t,h//8,4096),device='cuda',dtype=torch.float8_e4m3fn),torch.empty((t,h//8,128),device='cuda',dtype=torch.float8_e8m0fnu),torch.empty((t,h),device='cuda'),torch.empty((t,h),device='cuda')]
    vals=[q,packed.flatten(),ids if config else ids.long()*1056+1,ptr,cos,sin,pos,*out,None,None,None,sink,None,scale,False,None,0,0,0,0,True,None]
    if config:
        vals[18:23]=[config[k] for k in ['cache_scales','cache_page_size','cache_num_rows','cache_data_page_stride','cache_scale_page_stride']]
    if qscale is not None:vals[17]=True;vals[-1]=qscale
    native=tuple(b.convert(x) if isinstance(x,b.tensor_cls) else x for x in vals)
    def call():
        module._set_current_hip_stream(b.get_stream(b.get_device()))
        module.fused_dsv41_mxfp8_fwd(*native)
        return out
    call._tensors=vals
    call();return call,out

def candidate(tag,q,q8,qs,packed,ids,ptr,empty,cos,sin,pos,sink,scale,debug=None,config=None):
    t,h,_=q.shape;n=packed.shape[0]
    out=[torch.empty((t,h//8,4096),device='cuda',dtype=torch.float8_e4m3fn),torch.empty((t,h//8,128),device='cuda',dtype=torch.float8_e8m0fnu),torch.empty((t,h),device='cuda'),torch.empty((t,h),device='cuda')]
    a=Kargs(q8.data_ptr(),qs.data_ptr(),packed.data_ptr(),packed.data_ptr()+512,packed.data_ptr(),packed.data_ptr()+512,sink.data_ptr(),0,out[3].data_ptr(),ptr.data_ptr(),ids.data_ptr(),empty.data_ptr(),ids.data_ptr(),t,h,n,n,h*512,512,h*16,16,h*512,512,h,528,528,scale,out[2].data_ptr(),out[0].data_ptr(),out[1].data_ptr(),cos.data_ptr(),sin.data_ptr(),pos.data_ptr(),q.data_ptr(),debug.data_ptr() if debug is not None else 0,int(pos.dtype==torch.int64),0)
    if tag.startswith(('row_','legacy_','paged')):
        a.cache_mode=1;a.prefix_capacity=ids.numel();a.pool_bytes=packed.numel()
        if config:
            a.cache_mode=2;a.page_size=config['cache_page_size'];a.cache_rows=config['cache_num_rows']
            a.unified_kv_scale_ptr=config['cache_scales'].data_ptr();a.scale_bytes=config['cache_scales'].numel()
            a.data_page_stride=config['cache_data_page_stride'];a.scale_page_stride=config['cache_scale_page_stride']
    arg=(ct.c_void_p*1)(ct.addressof(a))
    def call():
        checked(hip.hipModuleLaunchKernel(functions[tag],t,h//64,1,256,1,1,0,torch.cuda.current_stream().cuda_stream,arg,None))
        return out
    call._alive=(a,arg,q,q8,qs,packed,ids,ptr,empty,cos,sin,pos,sink,debug,config)
    call();return call,out

node=next(n for n in ast.parse((BASE/'decode-pipeline-opt-20261021/bench.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='run_case')
source=ast.unparse(node)
prefix=source[:source.index('    calls, outputs =')]
if os.environ.get('SCAN'):
    prefix=prefix.replace("    assert fixture['signature'] == next((x for x in historical['rows'] if x['name'] == name))['signature']", "    # New scan fixtures have no historical signature; save the generated signature below.")
suffix=r'''
    q8=torch.empty_like(q,dtype=torch.float8_e4m3fn)
    qs=torch.empty((t,h,16),device='cuda',dtype=torch.uint8)
    att=torch.empty_like(q)
    cast=[torch.empty((t,h//8,4096),device='cuda',dtype=torch.float8_e4m3fn),torch.empty((t,h//8,128),device='cuda',dtype=torch.float8_e8m0fnu)]
    pos64=pos.long();empty=torch.zeros(t+1,device='cuda',dtype=torch.int32)
    pids,eids=[x.flatten() for x in scopes]
    pp=torch.arange(t+1,device='cuda',dtype=torch.int32)*scopes[0].shape[1]
    ep=torch.arange(t+1,device='cuda',dtype=torch.int32)*scopes[1].shape[1]
    data,codes=packed[:,:512].view(torch.float8_e4m3fn),packed[:,512:]
    def prepare():
        pr.q_prepare[(t*h//8,)](q,q8,qs,pos,cos,sin,h,True,ROWS=8,num_warps=4,enable_fp_fusion=False)
    def attention():
        return pr.mla_sparse_prefill_v41(q8,qs,data,codes,pids,pp,data,codes,eids,ep,sink,fixture['sm_scale'],out=att,backend='opus')
    def full_pr():
        prepare();attention()
        pr.inverse_rope_group_quant(att,pos64,cos,sin,num_groups=h//8,quant_group_size=32,scale_layout='row',x_fp8=cast[0],x_scale=cast[1])
        return cast
    full_pr()
    calls,outputs={},{}
    calls['retained'],outputs['retained']=baseline(q,packed,ids,ptr,cos,sin,pos,sink,fixture['sm_scale'])
    calls['retained_paged'],outputs['retained_paged']=baseline(q,paged,ids,ptr,cos,sin,pos,sink,fixture['sm_scale'],config=kw)
    for tag in ['epilogue','raw']:
        direct,out=candidate(tag,q,q8,qs,packed,ids,ptr,empty,cos,sin,pos,sink,fixture['sm_scale'])
        if tag=='epilogue':
            def full_epi(call=direct):prepare();return call()
            calls[tag]=full_epi
        else:calls[tag]=direct
        outputs[tag]=out
    calls['pr_full']=full_pr;outputs['pr_full']=cast
    if integrated:
        os.environ['AITER_ASM_DIR']=str(BASE/'aiter-dsv41-pr-fusion-20261022/hsa')
        calls['integrated'],outputs['integrated']=baseline(q,packed,ids,ptr,cos,sin,pos,sink,fixture['sm_scale'],module=integrated)
        calls['integrated_paged'],outputs['integrated_paged']=baseline(q,paged,ids,ptr,cos,sin,pos,sink,fixture['sm_scale'],config=kw,module=integrated)
        calls['integrated_prepared'],outputs['integrated_prepared']=baseline(q8,packed,ids,ptr,cos,sin,pos,sink,fixture['sm_scale'],module=integrated,qscale=qs)
        calls['retained_prepared'],outputs['retained_prepared']=baseline(q8,packed,ids,ptr,cos,sin,pos,sink,fixture['sm_scale'],qscale=qs)
        for a0,a1 in zip(outputs['integrated'],outputs['integrated_prepared']):torch.testing.assert_close(a0.view(torch.uint8),a1.view(torch.uint8),rtol=0,atol=0)
        for a0,a1 in zip(outputs['integrated'],outputs['integrated_paged']):torch.testing.assert_close(a0.view(torch.uint8),a1.view(torch.uint8),rtol=0,atol=0)
    encoded=ids.long()*1056+1
    calls['row_raw'],outputs['row_raw']=candidate('legacy_check_raw',q,q8,qs,packed,encoded,ptr,empty,cos,sin,pos,sink,fixture['sm_scale'])
    calls['paged_raw'],outputs['paged_raw']=candidate('paged128_check_raw',q,q8,qs,paged.flatten(),ids,ptr,empty,cos,sin,pos,sink,fixture['sm_scale'],config=kw)
    for tag in ['row_raw','paged_raw']:
        for x,y in zip(outputs[tag],outputs['raw']):torch.testing.assert_close(x.view(torch.uint8),y.view(torch.uint8),rtol=0,atol=0)
    if integrated:
        selected=h==128 and t<=320 and ids.numel()>=t*1024
        for tag,ref in [('integrated','row_raw' if selected else 'retained'),('integrated_paged','paged_raw' if selected else 'retained_paged')]:
            for x,y in zip(outputs[tag],outputs[ref]):torch.testing.assert_close(x.view(torch.uint8),y.view(torch.uint8),rtol=0,atol=0)
    calls['pr_attention']=attention;outputs['pr_attention']=[att]
    calls['q_prepare']=prepare;outputs['q_prepare']=[q8,qs]
    for a0,a1 in zip(outputs['raw'],outputs['epilogue']):
        torch.testing.assert_close(a0.view(torch.uint8),a1.view(torch.uint8),rtol=0,atol=0)
    debug=torch.empty_like(q,dtype=torch.float32)
    dbg_call,dbg_out=candidate('raw',q,q8,qs,packed,ids,ptr,empty,cos,sin,pos,sink,fixture['sm_scale'],debug)
    errors=[]
    for query in [0,t//2,t-1]:
        selected=[]
        for scope in fixture['scopes']:
            ix=torch.searchsorted(scope['used'],scope['indices'][query].long())
            selected.append(matched.decode_records(scope['packed'][ix]).cuda())
        kv=torch.cat(selected).float()
        qr=pr.rotate(q[query:query+1],cos,sin,pos[query:query+1]).bfloat16()
        qref,qsref=pr.quantize_fp8(qr)
        qref=qref.float()*torch.exp2(qsref.float()-127).repeat_interleave(32,-1)
        logits=qref@kv.T*fixture['sm_scale']
        probs=torch.cat((logits,sink[:,None]),-1).softmax(-1)[:,:len(kv)]
        expected=pr.rotate((probs@kv).bfloat16()[None],cos,sin,pos[query:query+1],True)[0]
        torch.testing.assert_close(debug[query],expected,rtol=.02,atol=.001)
        err=pr.relative(debug[query],expected);assert err<.005
        for tag in ['raw','epilogue','retained']:
            torch.testing.assert_close(outputs[tag][2][query],logits.max(-1).values,rtol=1e-4,atol=3e-5)
            torch.testing.assert_close(outputs[tag][3][query],logits.logsumexp(-1),rtol=1e-4,atol=3e-5)
        errors.append(err)
    delta=pr.relative(pr.dequantize(*outputs['raw'][:2]),pr.dequantize(*outputs['retained'][:2]))
    assert delta<.015,delta
    medians,samples,checks=measure(calls,outputs,False)
    return dict(name=name,case=case,signature=fixture['signature'],median_us=medians,samples_us=samples,replay_checks=checks,dense_errors=errors,versus_retained_l2=delta)
'''
b.__dict__.update(baseline=baseline,candidate=candidate,Kargs=Kargs,integrated=integrated,os=os)
exec(compile(prefix+suffix,'full_fusion_benchmark','exec'),b.__dict__)
report={'complete':False,'scope':'Q RoPE/quant through output inverse RoPE/quant; fused includes max/LSE, PR does not. No debug stores in timing. GPU6, clocks unlocked.','rows':[]}
filename=('integrated_scan.json' if os.environ.get('SCAN') else 'integrated_benchmark.json') if integrated else 'scan.json' if os.environ.get('SCAN') else 'benchmark.json'
for case in json.loads(os.environ['SCAN_CASES']) if os.environ.get('SCAN_CASES') else b.matched.CASES:
    row=b.run_case(case,{},pr=pr);report['rows'].append(row)
    (WORK/filename).write_text(json.dumps(report,indent=2))
    print(row['name'],row['median_us'],row['dense_errors'],flush=True)
    gc.collect();torch.cuda.empty_cache()
report['complete']=True
(WORK/filename).write_text(json.dumps(report,indent=2))
