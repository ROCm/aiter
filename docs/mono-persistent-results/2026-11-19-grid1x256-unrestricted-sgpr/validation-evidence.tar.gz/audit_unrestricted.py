"""Summarize immutable evidence; this script never launches work on the GPU."""
import hashlib,json,re,statistics,sys,xml.etree.ElementTree as ET
from collections import Counter
from pathlib import Path
root=Path(__file__).resolve().parent
r=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else root

def host_path(p):
 return root/Path(p).relative_to('/validation')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=root/'checkout/aiter/ops/triton/_gluon_kernels/gfx1250/quant/fused_mxfp8_quant.py'
weights={i for i,t in enumerate(source.read_text().splitlines(),1) if t.strip().startswith(('gq = gl.load(', 'gk = gl.load('))}
records={}
for p in [r/'runtime-launch-map.jsonl',r/'trace-current-jit.jsonl',r/'target-wrapper-map.jsonl']:
 if not p.exists():continue
 for s in p.read_text().splitlines():
  e=json.loads(s)
  if 'PERSISTENT_1' in e['kernel'] or '_fused_dual_rmsnorm_mxfp8_quant_ps_kernel' in e['kernel']:
   records[e['hash']]=e
out=[]
for e in records.values():
 asm=host_path(next(v for k,v in e['files'].items() if k.endswith('.amdgcn')))
 metadata=json.loads(host_path(next(v for k,v in e['files'].items() if k.endswith('.json'))).read_text())
 assert 'amdgpu-num-sgpr' not in str(metadata.get('llvm_fn_attrs',[])),metadata
 text=asm.read_text();loc=None;fmap={};mem=[];exceptions=[];refs=[];instructions=[]
 for i,line in enumerate(text.splitlines(),1):
  f=re.match(r'\s*\.file\s+(\d+)\s+"([^"]+)"(?:\s+"([^"]+)")?',line)
  if f:fmap[int(f[1])]=str(Path(f[2])/f[3]) if f[3] else f[2]
  m=re.match(r'\s*\.loc\s+(\d+)\s+(\d+)',line)
  if m:loc=(int(m[1]),int(m[2]))
  if not re.match(r'\s*(s_|v_|buffer_|global_|flat_|ds_)',line):continue
  instructions.append(line.strip())
  regs={int(v) for v in re.findall(r'\bs(\d+)\b',line)}
  for a,b in re.findall(r'\bs\[(\d+):(\d+)\]',line):regs.update(range(int(a),int(b)+1))
  if regs & {104,105}:refs.append({'line':i,'instruction':line.strip()})
  if re.match(r'\s*(buffer|global|flat)_(load|store)',line):
   item={'line':i,'instruction':line.strip(),'location':loc};mem.append(item)
   if 'scope:SCOPE_DEV' not in line:
    assert '_load' in line and loc and fmap.get(loc[0])=='/validation/checkout/'+str(source.relative_to(root/'checkout')) and loc[1] in weights,(asm,item,fmap)
    exceptions.append(item)
   if '_store' in line:assert 'th:TH_STORE_HT' in line,(asm,item)
 # s104/s105 are unrestricted for Triton/Gluon.
 resources={k:int(re.search(r'\.'+k+r':\s+(\d+)',text)[1]) for k in ['vgpr_count','sgpr_count','group_segment_fixed_size','private_segment_fixed_size','wavefront_size']}
 files={k:{'path':str(host_path(v)),'sha256':sha(host_path(v))} for k,v in e['files'].items()}
 out.append(dict(kernel=e['kernel'],hash=e['hash'],files=files,resources=resources,instruction_count=len(instructions),memory=mem,immutable_weight_exceptions=exceptions,asm_only_sgpr_rule_applies=False,sgpr_104_105_references=refs))
(r/'all-real-jit-audit.json').write_text(json.dumps({'source_sha256':sha(source),'source_weight_lines':sorted(weights),'variants':out},indent=2)+'\n')
# Correlate each entire timing case with the host's 100 ms PID samples.
samples=[];meta={}
for s in (root/'gpu-processes.jsonl').read_text().splitlines():
 e=json.loads(s);samples.append(e);meta.update(e.get('new',{}))
metrics=[json.loads(s) for s in (root/'gpu-metrics.jsonl').read_text().splitlines()]
audit=[];accepted=[]
for p in sorted(r.glob('performance-*.json')):
 data=json.loads(p.read_text())
 for case in data['results']:
  window=[e for e in samples if case['started_utc']<=e['time']<=case['finished_utc']]
  pids=sorted({pid for e in window for pid in e['pids']})
  rel='/validation/'+str(p.relative_to(root))
  expected=[int(pid) for pid,x in meta.items() if 'bench_mono_persistent' in x.get('cmdline','') and rel in x.get('cmdline','')]
  foreign=[pid for pid in pids if pid not in expected]
  entry=dict(file=p.name,op=case['op'],shape=case['input_storage_shape'],cache=case['cache'],samples=len(window),pids=pids,expected_pids=expected,foreign_pids=foreign,clean=bool(window) and not foreign)
  n=case['native'];ps=case['persistent'];delta=ps['median_us']-n['median_us'];noise=n['p90_us']-n['p10_us']
  decision='regression' if delta>noise and ps['p10_us']>n['p90_us'] else ('improvement' if -delta>noise and ps['p90_us']<n['p10_us'] else 'inconclusive')
  entry.update(decision=decision,native=n,persistent=ps,ratio=ps['median_us']/n['median_us'],native_noise_us=noise,tested_commit=data['aiter_commit'])
  clocks=[];powers=[];temps=[];throttles=[]
  for m in metrics:
   if not case['started_utc']<=m['time']<=case['finished_utc']:continue
   try:g=m['metrics']['gpu_data'][0]
   except (KeyError,TypeError):continue
   clocks.extend(v['clk']['value'] for k,v in g['clock'].items() if k.startswith('gfx_') and isinstance(v.get('clk'),dict))
   powers.append(g['power']['socket_power']['value']);temps.append(g['temperature']['hotspot']['value'])
   throttles.append(g['throttle']['ppt_violation_status'])
  entry['telemetry']={'gfx_mhz_range':[min(clocks),max(clocks)] if clocks else None,'power_w_range':[min(powers),max(powers)] if powers else None,'hotspot_c_range':[min(temps),max(temps)] if temps else None,'ppt_status_samples':throttles}
  audit.append(entry)
(r/'timing-process-audit.json').write_text(json.dumps(audit,indent=2)+'\n')
lines=['| Profile | Op | Input storage | Cache | Native median / P10 / P90 (us) | PS median / P10 / P90 (us) | PS/native | Decision |','| --- | --- | --- | --- | ---: | ---: | ---: | --- |']
for e in audit:
 fmt=lambda x:' / '.join(f'{x[k]:.6f}' for k in ['median_us','p10_us','p90_us'])
 lines.append('| '+ ' | '.join([e['file'].removeprefix('performance-').removesuffix('.json'),e['op'],str(e['shape']),e['cache'],fmt(e['native']),fmt(e['persistent']),f'{e["ratio"]:.6f}',e['decision'] if e['clean'] else 'contaminated'])+' |')
(r/'performance-table.md').write_text('\n'.join(lines)+'\n')
counts=Counter(c.attrib['name'].split('[')[0] for c in ET.parse(r/'correctness-current.xml').iter('testcase'))
(r/'test-coverage.json').write_text(json.dumps(dict(counts),indent=2)+'\n')
print(json.dumps({'real_jit_variants':len(out),'ut_counts':dict(counts),'perf_cases':len(audit),'clean':sum(e['clean'] for e in audit),'decisions':dict(Counter(e['decision'] for e in audit))},indent=2))
