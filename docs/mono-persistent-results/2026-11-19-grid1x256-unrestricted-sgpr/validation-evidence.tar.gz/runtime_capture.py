"""Record actual wrapper JIT loads and Python launches during acceptance tests."""
import pathlib,json,os,datetime
import pytest
r=pathlib.Path(os.environ["MONO_RESULTS"]);loaded={};context={}
def on_load(module,function,name,metadata_group,hash):
 loaded[function]={"kernel":name,"hash":hash,"files":metadata_group}
def on_launch(lazy):
 data=lazy.get()
 record={**context,**loaded[data["function"]],"time":datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (r/(os.environ.get("MONO_JIT_MAP_NAME","runtime-launch-map")+".jsonl")).open("a") as f:f.write(json.dumps(record,default=str)+"\n")
def pytest_sessionstart(session):
 import triton
 triton.knobs.runtime.kernel_load_end_hook.add(on_load)
 triton.knobs.runtime.launch_enter_hook.add(on_launch)
def pytest_runtest_setup(item):
 global context
 context={"nodeid":item.nodeid,"parameters":getattr(getattr(item,"callspec",None),"params",{})}
