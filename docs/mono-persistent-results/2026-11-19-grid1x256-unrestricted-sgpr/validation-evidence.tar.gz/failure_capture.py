"""Capture original pytest failure tensors before any source repair."""
import os,json,pathlib,traceback,hashlib,datetime
import pytest

def pack(x,depth=0):
 import torch
 if isinstance(x,torch.Tensor):
  return {"tensor":x.detach().cpu(),"shape":tuple(x.shape),"stride":x.stride(),"dtype":str(x.dtype),"device":str(x.device),"storage_offset":x.storage_offset()}
 if depth<3 and isinstance(x,(tuple,list)): return [pack(v,depth+1) for v in x]
 if depth<3 and isinstance(x,dict): return {str(k):pack(v,depth+1) for k,v in x.items()}
 if isinstance(x,(str,int,float,bool,type(None))): return x
 return repr(type(x))

@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item,call):
 outcome=yield
 report=outcome.get_result()
 if not report.failed or call.excinfo is None: return
 import torch
 d=pathlib.Path(os.environ["MONO_RESULTS"])/"failures"/datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%f")/hashlib.sha256(item.nodeid.encode()).hexdigest()[:16]
 d.mkdir(parents=True,exist_ok=True)
 (d/"failure.txt").write_text(item.nodeid+"\n"+str(report.longrepr))
 frames={}
 try:
  for entry in call.excinfo.traceback:
   if "test_mono_persistent.py" in str(entry.path):
    frames[str(entry.lineno)]={k:pack(v) for k,v in entry.frame.f_locals.items()}
  torch.save({"nodeid":item.nodeid,"frames":frames,"cpu_rng":torch.get_rng_state()},d/"case.pt")
 except Exception:
  (d/"capture-error.txt").write_text(traceback.format_exc())
