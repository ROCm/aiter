"""Validate the frozen candidate in one exclusive window; no model claims."""
from pathlib import Path
from collections import Counter
import csv
import json
import os
import re
import subprocess
import xml.etree.ElementTree as ET

r = Path('/validation/sgpr-unrestricted')
r.mkdir(exist_ok=True)
(r / 'logs').mkdir(exist_ok=True)
os.environ['MONO_RESULTS'] = str(r)


def run(name, args):
    with (r / 'logs' / (name + '.log')).open('w') as out:
        subprocess.run(args, stdout=out, stderr=subprocess.STDOUT, check=True)


run('correctness-current', ['python', '-m', 'pytest', '-p', 'failure_capture', '-p', 'runtime_capture',
    'op_tests/triton_tests/quant/test_mono_persistent.py', '-ra', '-v', '--junitxml=/validation/sgpr-unrestricted/correctness-current.xml'])
cases = list(ET.parse(r / 'correctness-current.xml').iter('testcase'))
assert len(cases) == 108, len(cases)
assert all(not any(c.find(k) is not None for k in ['failure', 'error', 'skipped']) for c in cases)
print('108 strict UT cases passed', flush=True)

os.environ['MONO_JIT_MAP_NAME'] = 'trace-current-jit'
run('launch-current', ['rocprofv3', '--kernel-trace', '--output-format', 'csv',
    '--output-directory', '/validation/sgpr-unrestricted/launch-current-trace', '--',
    'python', '-m', 'pytest', '-p', 'failure_capture', '-p', 'runtime_capture',
    'op_tests/triton_tests/quant/test_mono_persistent.py', '-k', 'graph_replay', '-ra', '-v'])
traces = list((r / 'launch-current-trace').glob('*/*kernel_trace.csv'))
assert len(traces) == 1, traces
counts = Counter()
for row in csv.DictReader(traces[0].open()):
    name = row['Kernel_Name']
    if 'PERSISTENT_1' not in name and '_fused_dual_rmsnorm_mxfp8_quant_ps_kernel' not in name:
        continue
    assert [int(row['Grid_Size_' + a]) for a in 'XYZ'] == [128, 256, 1], row
    assert [int(row['Workgroup_Size_' + a]) for a in 'XYZ'] == [128, 1, 1], row
    counts[name] += 1
assert sum(counts.values()) == 336 and len(counts) == 8, counts
(r / 'launch-current-gate.json').write_text(json.dumps({'passed': True, 'work_item_grid': [128, 256, 1],
    'workgroup': [128, 1, 1], 'tg_grid': [1, 256, 1], 'counts': dict(counts)}, indent=2) + '\n')

records = {}
for line in (r / 'trace-current-jit.jsonl').read_text().splitlines():
    e = json.loads(line)
    if 'PERSISTENT_1' in e['kernel'] or '_fused_dual_rmsnorm_mxfp8_quant_ps_kernel' in e['kernel']:
        records[e['hash']] = e
audits = []
for e in records.values():
    asm_path = Path(next(v for k, v in e['files'].items() if k.endswith('.amdgcn')))
    assembly = asm_path.read_text()
    metadata_path = Path(next(v for k, v in e['files'].items() if k.endswith('.json')))
    metadata = json.loads(metadata_path.read_text())
    assert 'amdgpu-num-sgpr' not in str(metadata.get('llvm_fn_attrs', [])), metadata
    refs, memory = [], []
    for ln, line in enumerate(assembly.splitlines(), 1):
        if not re.match(r'\s*(?:s_|v_|buffer_|global_|flat_|ds_)', line):
            continue
        nums = {int(x) for x in re.findall(r'\bs(\d+)\b', line)}
        for a, b in re.findall(r'\bs\[(\d+):(\d+)\]', line):
            nums.update(range(int(a), int(b) + 1))
        if nums & {104, 105}:
            refs.append({'line': ln, 'instruction': line.strip()})
        if re.match(r'\s*(?:buffer|global|flat)_(?:load|store)', line):
            memory.append(line.strip())
            assert 'scope:SCOPE_DEV' in line, (asm_path, ln, line)
            if '_store' in line:
                assert 'th:TH_STORE_HT' in line, (asm_path, ln, line)
    # The s104/s105 rule applies only to ASM kernels, not compiled Gluon.
    audits.append({'kernel': e['kernel'], 'hash': e['hash'], 'files': e['files'],
                  'asm_only_sgpr_rule_applies': False, 'sgpr_104_105_references': refs, 'memory_instructions': memory})
(r / 'jit-current-audit.json').write_text(json.dumps(audits, indent=2) + '\n')
print('Real launch and op ISA gates passed; main-kernel ABI/join remain unverified', flush=True)

# These are source-derived full/balanced verify shapes, not model traces.
# c256 A03 reuses the same [384,1792] case as c64.
for label, rows, width, ops in [
    ('c16-verify-proxy', '96', '2048', ['a03', 'a09', 'a09-qat']),
    ('c64-verify-proxy', '384', '2048', ['a03', 'a09', 'a09-qat']),
    ('c128-verify-proxy', '192', '8192', ['a03', 'a09', 'a09-qat']),
    ('c256-verify-proxy', '384', '8192', ['a09', 'a09-qat']),
]:
    run('performance-' + label, ['python', '-m', 'op_tests.op_benchmarks.triton.bench_mono_persistent',
        '--ops', *ops, '--rows', rows, '--a09-width', width, '--cache', 'both', '--trials', '15',
        '--output', '/validation/sgpr-unrestricted/performance-' + label + '.json'])
    print(label + ' isolated-op timing complete', flush=True)
