"""Validate the frozen candidate in one exclusive window; no model claims."""
from pathlib import Path
from collections import Counter
import csv
import json
import os
import re
import subprocess
import xml.etree.ElementTree as ET

r = Path('/validation/round2')
r.mkdir(exist_ok=True)
(r / 'logs').mkdir(exist_ok=True)
os.environ['MONO_RESULTS'] = str(r)


def run(name, args):
    with (r / 'logs' / (name + '.log')).open('w') as out:
        subprocess.run(args, stdout=out, stderr=subprocess.STDOUT, check=True)


run('correctness-current', ['python', '-m', 'pytest', '-p', 'failure_capture', '-p', 'runtime_capture',
    'op_tests/triton_tests/quant/test_mono_persistent.py', '-ra', '-v', '--junitxml=/validation/round2/correctness-current.xml'])
cases = list(ET.parse(r / 'correctness-current.xml').iter('testcase'))
assert len(cases) == 108, len(cases)
assert all(not any(c.find(k) is not None for k in ['failure', 'error', 'skipped']) for c in cases)
print('108 strict UT cases passed', flush=True)

os.environ['MONO_JIT_MAP_NAME'] = 'trace-current-jit'
run('launch-current', ['rocprofv3', '--kernel-trace', '--output-format', 'csv',
    '--output-directory', '/validation/round2/launch-current-trace', '--',
    'python', '-m', 'pytest', '-p', 'failure_capture', '-p', 'runtime_capture',
    'op_tests/triton_tests/quant/test_mono_persistent.py', '-k', 'graph_replay', '-ra', '-v'])
traces = list((r / 'launch-current-trace').glob('*/*kernel_trace.csv'))
assert len(traces) == 1, traces
counts = Counter()
for row in csv.DictReader(traces[0].open()):
    name = row['Kernel_Name']
    if 'PERSISTENT_1' not in name and '_fused_dual_rmsnorm_mxfp8_quant_ps_kernel' not in name:
        continue
    assert [int(row['Grid_Size_' + a]) for a in 'XYZ'] == [2048, 16, 1], row
    assert [int(row['Workgroup_Size_' + a]) for a in 'XYZ'] == [128, 1, 1], row
    counts[name] += 1
assert sum(counts.values()) == 336 and len(counts) == 8, counts
(r / 'launch-current-gate.json').write_text(json.dumps({'passed': True, 'work_item_grid': [2048, 16, 1],
    'workgroup': [128, 1, 1], 'tg_grid': [16, 16, 1], 'counts': dict(counts)}, indent=2) + '\n')

records = {}
for line in (r / 'trace-current-jit.jsonl').read_text().splitlines():
    e = json.loads(line)
    if 'PERSISTENT_1' in e['kernel'] or '_fused_dual_rmsnorm_mxfp8_quant_ps_kernel' in e['kernel']:
        records[e['hash']] = e
audits = []
for e in records.values():
    asm_path = Path(next(v for k, v in e['files'].items() if k.endswith('.amdgcn')))
    assembly = asm_path.read_text()
    refs, memory, weight_exceptions = [], [], []
    source = Path('/validation/checkout/aiter/ops/triton/_gluon_kernels/gfx1250/quant/fused_mxfp8_quant.py')
    weight_lines = {i for i, t in enumerate(source.read_text().splitlines(), 1) if t.strip().startswith(('gq = gl.load(', 'gk = gl.load('))}
    file_map = {}
    location = None
    for ln, line in enumerate(assembly.splitlines(), 1):
        f = re.match(r'\s*\.file\s+(\d+)\s+"([^"]+)"(?:\s+"([^"]+)")?', line)
        if f:
            file_map[int(f[1])] = str(Path(f[2]) / f[3]) if f[3] else f[2]
        loc = re.match(r'\s*\.loc\s+(\d+)\s+(\d+)', line)
        if loc:
            location = (int(loc[1]), int(loc[2]))
        if not re.match(r'\s*(?:s_|v_|buffer_|global_|flat_|ds_)', line):
            continue
        nums = {int(x) for x in re.findall(r'\bs(\d+)\b', line)}
        for a, b in re.findall(r'\bs\[(\d+):(\d+)\]', line):
            nums.update(range(int(a), int(b) + 1))
        if nums & {104, 105}:
            refs.append({'line': ln, 'instruction': line.strip()})
        if re.match(r'\s*(?:buffer|global|flat)_(?:load|store)', line):
            memory.append(line.strip())
            if 'scope:SCOPE_DEV' not in line:
                assert '_load' in line and location is not None, (asm_path, ln, line)
                assert file_map.get(location[0]) == str(source) and location[1] in weight_lines, (asm_path, ln, location, file_map, line)
                weight_exceptions.append({'line': ln, 'source_line': location[1], 'instruction': line.strip()})
            if '_store' in line:
                assert 'th:TH_STORE_HT' in line, (asm_path, ln, line)
    assert not refs, (asm_path, refs)
    audits.append({'kernel': e['kernel'], 'hash': e['hash'], 'files': e['files'],
                  'reserved_sgpr_references': refs, 'memory_instructions': memory, 'immutable_weight_exceptions': weight_exceptions})
(r / 'jit-current-audit.json').write_text(json.dumps(audits, indent=2) + '\n')
print('Real launch and op ISA gates passed; main-kernel ABI/join remain unverified', flush=True)

# These are source-derived full/balanced verify shapes, not model traces.
# c256 A03 reuses the same [384,1792] case as c64.
for label, rows, width, ops in [
    ('c16-verify-proxy', '96', '2048', ['a03', 'a09', 'a09-qat']),
    ('c64-verify-proxy', '384', '2048', ['a03', 'a09', 'a09-qat']),
    ('c128-verify-proxy', '192', '8192', ['a03', 'a09', 'a09-qat']),
    ('c256-verify-proxy', '384', '8192', ['a09', 'a09-qat']),
]:
    run('performance-' + label, ['python', '-m', 'op_tests.op_benchmarks.triton.bench_mono_persistent',
        '--ops', *ops, '--rows', rows, '--a09-width', width, '--cache', 'both', '--trials', '15',
        '--output', '/validation/round2/performance-' + label + '.json'])
    print(label + ' isolated-op timing complete', flush=True)
