"""MLIR Python FlyROCDL Extension"""

import _mlir

import flydsl._mlir._mlir_libs._mlir.ir


class MmaOpCDNA3_MFMAType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(m: int, n: int, k: int, elem_ty_a: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_b: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_acc: flydsl._mlir._mlir_libs._mlir.ir.Type, *, context: _mlir.ir.Context | None = None) -> MmaOpCDNA3_MFMAType:
        """Create a MmaOpCDNA3_MFMAType with m, n, k dimensions and element types"""

class MmaOpCDNA4_MFMAScaleType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(m: int, n: int, k: int, elem_ty_a: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_b: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_acc: flydsl._mlir._mlir_libs._mlir.ir.Type, opsel_a: int = 0, opsel_b: int = 0, *, context: _mlir.ir.Context | None = None) -> MmaOpCDNA4_MFMAScaleType:
        """
        Create a MmaOpCDNA4_MFMAScaleType with m, n, k dimensions, element types, and optional opsel_a / opsel_b (compile-time lane index into the scale vector, default 0)
        """

class MmaOpGFX1250_WMMAType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(m: int, n: int, k: int, elem_ty_a: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_b: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_acc: flydsl._mlir._mlir_libs._mlir.ir.Type, sign_a: bool = False, sign_b: bool = False, clamp: bool = False, *, context: _mlir.ir.Context | None = None) -> MmaOpGFX1250_WMMAType:
        """
        Create a MmaOpGFX1250_WMMAType with m, n, k dimensions and element types. sign_a / sign_b / clamp are integer-only (iu4 / iu8) controls (signed operands / accumulator saturation); they must be false on the float paths.
        """

class MmaOpGFX1250_WMMAScaleType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(m: int, n: int, k: int, elem_ty_a: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_b: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_acc: flydsl._mlir._mlir_libs._mlir.ir.Type, opsel_a: int = 0, opsel_b: int = 0, mod_c: int = 0, reuse_a: bool = False, reuse_b: bool = False, block_size: int = 32, *, context: _mlir.ir.Context | None = None) -> MmaOpGFX1250_WMMAScaleType:
        """
        Create a MmaOpGFX1250_WMMAScaleType (MX-scaled WMMA, E8M0 block scale) with m, n, k dimensions, element types, optional opsel_a / opsel_b (compile-time lane index into the scale vector, default 0), the intrinsic mod_c / reuse_a / reuse_b attributes (default 0 / false), and block_size (16 or 32, default 32) selecting the V_WMMA_SCALE16 / V_WMMA_SCALE form
        """

class MmaOpGFX11_WMMAType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(m: int, n: int, k: int, elem_ty_a: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_b: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_acc: flydsl._mlir._mlir_libs._mlir.ir.Type, *, sign_a: bool = False, sign_b: bool = False, clamp: bool = False, context: _mlir.ir.Context | None = None) -> MmaOpGFX11_WMMAType:
        """
        Create a MmaOpGFX11_WMMAType with m, n, k dimensions and element types (RDNA3 / RDNA3.5 wave32 WMMA, v16 operand ABI). sign_a/sign_b/clamp are forwarded to the iu8/iu4 intrinsic for integer paths; must be false for fp16/bf16.
        """

class MmaOpGFX120X_WMMAType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(m: int, n: int, k: int, elem_ty_a: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_b: flydsl._mlir._mlir_libs._mlir.ir.Type, elem_ty_acc: flydsl._mlir._mlir_libs._mlir.ir.Type, *, sign_a: bool = False, sign_b: bool = False, clamp: bool = False, context: _mlir.ir.Context | None = None) -> MmaOpGFX120X_WMMAType:
        """
        Create a MmaOpGFX120X_WMMAType with m, n, k dimensions and element types (RDNA4 gfx1200 / gfx1201 wave32 WMMA, 16x16x16 with the v8 operand ABI). sign_a/sign_b/clamp must be false: fp16, bf16, and every fp8(E4M3FN)/bf8(E5M2) A/B combination are supported.
        """

class CopyOpCDNA3BufferCopyType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(bit_size: int, cache_modifier: int = 0, *, context: _mlir.ir.Context | None = None) -> CopyOpCDNA3BufferCopyType:
        """
        Create a CopyOpCDNA3BufferCopyType with the given bit size and cache_modifier (0=cached, 2=non-temporal)
        """

class CopyOpCDNA3BufferCopyLDSType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(bit_size: int, *, context: _mlir.ir.Context | None = None) -> CopyOpCDNA3BufferCopyLDSType:
        """Create a CopyOpCDNA3BufferCopyLDSType with the given bit size"""

class CopyOpCDNA3BufferAtomicType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(atomic_op: int, val_type: flydsl._mlir._mlir_libs._mlir.ir.Type, *, context: _mlir.ir.Context | None = None) -> CopyOpCDNA3BufferAtomicType:
        """Create a CopyOpCDNA3BufferAtomicType with atomic op and value type"""

class CopyOpGFX1250TDMType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(rank: int, num_warps: int, pad_interval: int = 0, pad_amount: int = 0, cache_modifier: int = 0, atomic_barrier: bool = False, early_timeout: bool = False, *, context: _mlir.ir.Context | None = None) -> CopyOpGFX1250TDMType:
        """
        Create a CopyOpGFX1250TDMType (N-D TDM Global<->LDS copy) with tensor rank (1-5), warp count, optional LDS padding (interval/amount in elements), cache modifier, and the descriptor atomic_barrier / early_timeout config bits (default false)
        """

class CopyOpCDNA4LdsReadTransposeType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(trans_granularity: int, bit_size: int, *, context: _mlir.ir.Context | None = None) -> CopyOpCDNA4LdsReadTransposeType:
        """
        Create a CopyOpCDNA4LdsReadTransposeType with transpose granularity and bit size
        """

class CopyOpCDNA4BufferLoadAsyncLDSType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(bit_size: int, *, context: _mlir.ir.Context | None = None) -> CopyOpCDNA4BufferLoadAsyncLDSType:
        """
        Create a CopyOpCDNA4BufferLoadAsyncLDSType with the given bit size (async BufferDesc -> Shared DMA; completion must be tracked with rocdl.asyncmark / rocdl.wait.asyncmark)
        """

class CopyOpCDNA4GlobalLoadAsyncLDSType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(bit_size: int, *, context: _mlir.ir.Context | None = None) -> CopyOpCDNA4GlobalLoadAsyncLDSType:
        """
        Create a CopyOpCDNA4GlobalLoadAsyncLDSType with the given bit size (async Global -> Shared DMA; completion must be tracked with rocdl.asyncmark / rocdl.wait.asyncmark)
        """
