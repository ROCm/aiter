"""MLIR Python FlyDSL Extension"""

from collections.abc import Sequence
from typing import overload

import _mlir

import flydsl._mlir._mlir_libs._mlir.ir
import flydsl._mlir.ir


class DLTensorAdaptor:
    def __init__(self, dlpack_capsule: object) -> None:
        """Create a DLTensorAdaptor from a DLPack capsule."""

    @property
    def shape(self) -> tuple:
        """Get tensor shape as tuple"""

    @property
    def stride(self) -> tuple:
        """Get tensor stride as tuple"""

    @property
    def data_ptr(self) -> int:
        """Get data pointer as int64"""

    @property
    def address_space(self) -> int:
        """Get address space (0=host, 1=device)"""

    @property
    def dtype(self) -> flydsl._mlir.ir.Type:
        """
        The dtype as an MLIR element type (ir Type); requires an active MLIR context
        """

    @property
    def dtype_id(self) -> tuple:
        """
        Context-free dtype id (code, bits, lanes) for use as a cache discriminator
        """

    @property
    def element_bits(self) -> int:
        """Element width in bits (bits * lanes), at sub-byte granularity"""

    def size_in_bytes(self) -> int:
        """Get total size in bytes"""

def infer_int_tuple_type(int_or_tuple, context: flydsl._mlir.ir.Context | None = None):
    """infer IntTupleType for given input"""

def rank(int_or_tuple: flydsl._mlir.ir.Value) -> int: ...

def depth(int_or_tuple: flydsl._mlir.ir.Value) -> int: ...

def has_none(int_or_tuple: flydsl._mlir.ir.Value) -> bool: ...

def is_profile_congruent(lhs: flydsl._mlir.ir.Value, rhs: flydsl._mlir.ir.Value) -> bool: ...

def is_profile_weakly_congruent(lhs: flydsl._mlir.ir.Value, rhs: flydsl._mlir.ir.Value) -> bool: ...

class IntTupleType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(int_or_tuple, context: flydsl._mlir.ir.Context | None = None):
        """Create an IntTupleType from Python int or tuple"""

    @property
    def rank(self) -> int: ...

    @property
    def depth(self) -> int: ...

    @property
    def is_leaf(self) -> bool: ...

    @property
    def is_static(self) -> bool: ...

    @property
    def get_static_leaf_int(self) -> int: ...

    @property
    def is_leaf_int(self) -> bool: ...

    @property
    def is_leaf_basis(self) -> bool: ...

    @property
    def get_leaf_as_basis(self) -> flydsl._mlir.ir.Type: ...

    def at(self, arg: int, /) -> flydsl._mlir.ir.Type: ...

class BasisType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @property
    def is_static(self) -> bool: ...

    @property
    def value(self) -> int: ...

    @property
    def modes(self) -> list[int]: ...

class TileType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(modes: object, *, context: _mlir.ir.Context | None = None) -> TileType:
        """Create a TileType from a list of modes or a single mode (leaf tile)"""

    @property
    def rank(self) -> int: ...

    @property
    def is_leaf(self) -> bool: ...

    def at(self, arg: int, /) -> flydsl._mlir.ir.Type: ...

class LayoutType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(shape: object, stride: object, *, context: _mlir.ir.Context | None = None) -> LayoutType:
        """Create a LayoutType with shape and stride"""

    @property
    def shape(self) -> flydsl._mlir.ir.Type: ...

    @property
    def stride(self) -> flydsl._mlir.ir.Type: ...

    @property
    def rank(self) -> int: ...

    @property
    def depth(self) -> int: ...

    @property
    def is_leaf(self) -> bool: ...

    @property
    def is_static(self) -> bool: ...

    @property
    def is_static_shape(self) -> bool: ...

    @property
    def is_static_stride(self) -> bool: ...

class SwizzleType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(mask: int, base: int, shift: int, *, context: _mlir.ir.Context | None = None) -> SwizzleType:
        """Create a SwizzleType"""

    @property
    def mask(self) -> int: ...

    @property
    def base(self) -> int: ...

    @property
    def shift(self) -> int: ...

class CoordSwizzleType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(mask: int, base_row: int, mode_row: Sequence[int], base_col: int, mode_col: Sequence[int], *, context: _mlir.ir.Context | None = None) -> CoordSwizzleType:
        """Create a CoordSwizzleType"""

    @property
    def mask(self) -> int: ...

    @property
    def base_row(self) -> int: ...

    @property
    def mode_row(self) -> list[int]: ...

    @property
    def base_col(self) -> int: ...

    @property
    def mode_col(self) -> list[int]: ...

class ComposedLayoutType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(inner: flydsl._mlir._mlir_libs._mlir.ir.Type, offset: object, outer: flydsl._mlir._mlir_libs._mlir.ir.Type, *, context: _mlir.ir.Context | None = None) -> ComposedLayoutType:
        """Create a ComposedLayoutType with inner, offset and outer"""

    @property
    def inner(self) -> flydsl._mlir.ir.Type: ...

    @property
    def offset(self) -> flydsl._mlir.ir.Type: ...

    @property
    def outer(self) -> flydsl._mlir.ir.Type: ...

    @property
    def rank(self) -> int: ...

    @property
    def depth(self) -> int: ...

    @property
    def is_leaf(self) -> bool: ...

    @property
    def is_static(self) -> bool: ...

    @property
    def is_static_outer(self) -> bool: ...

    @property
    def is_static_inner(self) -> bool: ...

    @property
    def is_static_offset(self) -> bool: ...

class PointerType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(elem_ty: flydsl._mlir._mlir_libs._mlir.ir.Type, address_space: object | None = None, alignment: int | None = None, *, context: _mlir.ir.Context | None = None) -> PointerType:
        """
        Create a PointerType. address_space accepts an int (Fly_AddressSpace case) or a target-specific MLIR Attribute (e.g. `#fly_rocdl.buffer_desc`).
        """

    @property
    def element_type(self) -> flydsl._mlir.ir.Type: ...

    @property
    def address_space(self) -> flydsl._mlir._mlir_libs._mlir.ir.Attribute: ...

    @property
    def alignment(self) -> int: ...

    @property
    def swizzle(self) -> flydsl._mlir.ir.Type: ...

class MemRefType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @overload
    @staticmethod
    def get(elem_ty: flydsl._mlir._mlir_libs._mlir.ir.Type, layout: flydsl._mlir._mlir_libs._mlir.ir.Type, address_space: object | None = None, alignment: int | None = None, *, context: _mlir.ir.Context | None = None) -> MemRefType:
        """
        Create a MemRefType. address_space accepts an int (Fly_AddressSpace case) or a target-specific MLIR Attribute (e.g. `#fly_rocdl.buffer_desc`).
        """

    @overload
    @staticmethod
    def get(elem_ty: flydsl._mlir._mlir_libs._mlir.ir.Type, shape_enc: Sequence[int], stride_enc: Sequence[int], use_32bit_stride: bool, alignment: int, *, context: _mlir.ir.Context | None = None) -> MemRefType:
        """
        Build a layout-dynamic MemRefType from encoded per-dim values: v>=0 static size/stride, v<0 dynamic with divisibility -v (same encoding as the cache signature). Python owns the layout state.
        """

    @property
    def element_type(self) -> flydsl._mlir.ir.Type: ...

    @property
    def layout(self) -> flydsl._mlir.ir.Type: ...

    @property
    def address_space(self) -> flydsl._mlir._mlir_libs._mlir.ir.Attribute: ...

    @property
    def alignment(self) -> int: ...

    @property
    def swizzle(self) -> flydsl._mlir.ir.Type: ...

    @property
    def leading_dim(self) -> object:
        """Return the first left-to-right mode whose stride is statically 1"""

class CoordTensorType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(base: object, layout: flydsl._mlir._mlir_libs._mlir.ir.Type, *, context: _mlir.ir.Context | None = None) -> CoordTensorType:
        """Create a CoordTensorType with base and layout"""

    @property
    def base(self) -> flydsl._mlir.ir.Type: ...

    @property
    def layout(self) -> flydsl._mlir.ir.Type: ...

    @property
    def rank(self) -> int: ...

    @property
    def depth(self) -> int: ...

    @property
    def is_leaf(self) -> bool: ...

    @property
    def is_static(self) -> bool: ...

class CopyAtomType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(copy_op: flydsl._mlir._mlir_libs._mlir.ir.Type, val_bits: int, *, context: _mlir.ir.Context | None = None) -> CopyAtomType:
        """Create a CopyAtomType with the given copy op type and value bits"""

    @property
    def copy_op(self) -> flydsl._mlir.ir.Type: ...

    @property
    def val_bits(self) -> int: ...

    @property
    def thr_layout(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tv_layout_src(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tv_layout_dst(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tv_layout_ref(self) -> flydsl._mlir.ir.Type: ...

class MmaAtomType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(mma_op: flydsl._mlir._mlir_libs._mlir.ir.Type, *, context: _mlir.ir.Context | None = None) -> MmaAtomType:
        """Create a MmaAtomType wrapping an MmaOpTypeInterface type"""

    @property
    def mma_op(self) -> flydsl._mlir.ir.Type: ...

    @property
    def thr_layout(self) -> flydsl._mlir.ir.Type: ...

    @property
    def shape_mnk(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tv_layout_a(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tv_layout_b(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tv_layout_c(self) -> flydsl._mlir.ir.Type: ...

class TiledCopyType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @property
    def copy_atom(self) -> flydsl._mlir.ir.Type: ...

    @property
    def layout_thr_val(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tile_mn(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tiled_tv_layout_src(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tiled_tv_layout_dst(self) -> flydsl._mlir.ir.Type: ...

class TiledMmaType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @property
    def mma_atom(self) -> flydsl._mlir.ir.Type: ...

    @property
    def atom_layout(self) -> flydsl._mlir.ir.Type: ...

    @property
    def permutation(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tile_size_mnk(self) -> flydsl._mlir.ir.Type: ...

    @property
    def thr_layout_vmnk(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tiled_tv_layout_a(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tiled_tv_layout_b(self) -> flydsl._mlir.ir.Type: ...

    @property
    def tiled_tv_layout_c(self) -> flydsl._mlir.ir.Type: ...

class CopyOpUniversalCopyType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(bitSize: int, *, context: _mlir.ir.Context | None = None) -> CopyOpUniversalCopyType:
        """Create a CopyOpUniversalCopyType with bit size"""

class CopyOpUniversalAtomicType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(atomic_op: int, val_type: flydsl._mlir._mlir_libs._mlir.ir.Type, syncscope: str = '', *, context: _mlir.ir.Context | None = None) -> CopyOpUniversalAtomicType:
        """
        Create a CopyOpUniversalAtomicType with atomic op, value type and sync scope
        """

class MmaOpUniversalFMAType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    @staticmethod
    def get(elem_ty: flydsl._mlir._mlir_libs._mlir.ir.Type, *, context: _mlir.ir.Context | None = None) -> MmaOpUniversalFMAType:
        """Create a MmaOpUniversalFMAType with element type"""

    @property
    def elem_ty(self) -> flydsl._mlir.ir.Type: ...

def set_llvm_option_bool(name: str, value: bool) -> bool:
    """Set an LLVM bool cl::opt at runtime; returns the previous value."""

def set_llvm_option_int(name: str, value: int) -> int:
    """Set an LLVM int cl::opt at runtime; returns the previous value."""

def set_llvm_option_str(name: str, value: str) -> str:
    """Set an LLVM string cl::opt at runtime; returns the previous value."""
