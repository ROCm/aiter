"""MLIR GPU Dialect"""

import _mlir

import flydsl._mlir._mlir_libs._mlir.ir


class AsyncTokenType(flydsl._mlir._mlir_libs._mlir.ir.Type):
    def __init__(self, cast_from_type: flydsl._mlir._mlir_libs._mlir.ir.Type) -> None: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    type_name: str = ...
    """(arg: object, /) -> str"""

    @staticmethod
    def get(context: _mlir.ir.Context | None = None) -> AsyncTokenType:
        """Gets an instance of AsyncTokenType in the same context"""

class ObjectAttr(flydsl._mlir._mlir_libs._mlir.ir.Attribute):
    def __init__(self, cast_from_attr: flydsl._mlir._mlir_libs._mlir.ir.Attribute) -> None: ...

    @property
    def type(self) -> flydsl._mlir._mlir_libs._mlir.ir.Type: ...

    static_typeid: flydsl._mlir._mlir_libs._mlir.ir.TypeID = ...
    """(arg: object, /) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID"""

    @property
    def typeid(self) -> flydsl._mlir._mlir_libs._mlir.ir.TypeID: ...

    def __repr__(self) -> str: ...

    attr_name: str = ...
    """(arg: object, /) -> str"""

    @staticmethod
    def get(target: flydsl._mlir._mlir_libs._mlir.ir.Attribute, format: int, object: bytes, properties: flydsl._mlir._mlir_libs._mlir.ir.DictAttr | None = None, kernels: flydsl._mlir._mlir_libs._mlir.ir.Attribute | None = None, context: _mlir.ir.Context | None = None) -> ObjectAttr:
        """Gets a gpu.object from parameters."""

    @property
    def target(self) -> flydsl._mlir._mlir_libs._mlir.ir.Attribute: ...

    @property
    def format(self) -> int: ...

    @property
    def object(self) -> bytes: ...

    @property
    def properties(self) -> flydsl._mlir._mlir_libs._mlir.ir.DictAttr | None: ...

    @property
    def kernels(self) -> flydsl._mlir._mlir_libs._mlir.ir.Attribute | None: ...
